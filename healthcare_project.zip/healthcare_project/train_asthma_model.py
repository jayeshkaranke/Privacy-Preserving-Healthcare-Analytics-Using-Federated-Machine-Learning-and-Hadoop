"""
Train and persist Asthma Classification Model using Kaggle Asthma Disease Dataset.
"""
import os
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib

def train_asthma_model():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, 'data', 'asthma_dataset.csv')
    model_path = os.path.join(base_dir, 'models', 'asthma_model.joblib')

    if not os.path.exists(data_path):
        url = 'https://raw.githubusercontent.com/solarwalker/asthma-disease-prediction-dataset/main/processed-data.csv'
        print(f"Downloading dataset from {url}...")
        df = pd.read_csv(url)
        df.to_csv(data_path, index=False)
    else:
        print(f"Loading local dataset from {data_path}...")
        df = pd.read_csv(data_path)

    features = [
        'Difficulty-in-Breathing', 'Dry-Cough', 'Nasal-Congestion', 'Sore-Throat', 
        'Tiredness', 'Runny-Nose', 'Pains', 'None_Sympton', 
        'Age_0-9', 'Age_10-19', 'Age_20-24', 'Age_25-59', 'Age_60+', 
        'Gender_Female', 'Gender_Male'
    ]

    print(f"Dataset shape: {df.shape}")
    sample_df = df.sample(n=50000, random_state=42)
    X = sample_df[features]
    y = sample_df['Asthma']

    print("Training RandomForest model on asthma symptom features...")
    model = RandomForestClassifier(n_estimators=60, max_depth=8, random_state=42)
    model.fit(X, y)

    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    joblib.dump(model, model_path)
    print(f"Model saved to {model_path}")

    # Validation
    val_sample = df.sample(n=5000, random_state=99)
    acc = model.score(val_sample[features], val_sample['Asthma'])
    print(f"Validation Sample Accuracy: {acc * 100:.2f}%")

if __name__ == '__main__':
    train_asthma_model()
