"""
test_full_pipeline.py - Comprehensive End-to-End Test Suite
Tests:
1. Hadoop WebHDFS connection (Port 9870)
2. Dataset uploads to Hadoop HDFS (Hospital A, B, C)
3. Federated Learning training pipeline (FedAvg parameter aggregation)
4. Multi-disease Risk Analysis assessments (Diabetes, Heart, Hypertension, Asthma)
5. SQLite Database persistence & history retrieval
6. Flask web routes and UI endpoints
"""

import os
import sys
import json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from services.hadoop_service import (
    check_hadoop_connection,
    upload_datasets_to_hdfs,
    get_hdfs_storage_status
)
from services.federated_service import (
    run_federated_pipeline,
    get_federated_status,
    predict_diabetes_risk
)
from services.disease_service import (
    analyze_disease_risk,
    calculate_bmi
)
from services.db_service import (
    init_db,
    save_assessment,
    get_all_assessments,
    get_recent_assessments,
    get_total_assessments_count
)
from app import app


def test_hadoop_pipeline():
    print("\n" + "=" * 60)
    print("STEP 1: TESTING HADOOP WebHDFS STORAGE INTEGRATION")
    print("=" * 60)

    # 1. Check connection
    conn = check_hadoop_connection()
    print(f"[*] NameNode Connection Status : {conn.get('status')}")
    print(f"[*] Storage Mode                : {conn.get('mode')}")
    print(f"[*] WebHDFS Endpoint            : {conn.get('endpoint')}")
    assert conn.get('is_connected') is True, f"WebHDFS connection failed: {conn.get('message')}"
    print("[+] SUCCESS: WebHDFS NameNode is ACTIVE and reachable on port 9870!")

    # 2. Upload datasets
    print("\n[*] Uploading Hospital A, B, and C datasets to HDFS...")
    upload_res = upload_datasets_to_hdfs()
    print(f"[*] Upload Mode    : {upload_res.get('mode')}")
    print(f"[*] Upload Success : {upload_res.get('success')}")
    print(f"[*] Message        : {upload_res.get('message')}")

    for detail in upload_res.get('details', []):
        print(f"    -> File: {detail.get('file')} | Status: {detail.get('status')} | HDFS Path: {detail.get('hdfs_path')}")
        assert detail.get('status') == 'Uploaded to HDFS'

    print("[+] SUCCESS: All hospital datasets successfully transferred to HDFS namespace!")

    # 3. Verify physical HDFS storage on disk
    hdfs_store = os.path.join(BASE_DIR, 'data', 'hdfs_storage', 'healthcare_dfs')
    hospitals = ['hospital_A', 'hospital_B', 'hospital_C']
    for h in hospitals:
        file_path = os.path.join(hdfs_store, h, f"{h}.csv")
        assert os.path.exists(file_path), f"HDFS file missing on disk: {file_path}"
        size_kb = round(os.path.getsize(file_path) / 1024, 1)
        print(f"[+] Verified HDFS block on disk: {h}/{h}.csv ({size_kb} KB)")


def test_federated_training_pipeline():
    print("\n" + "=" * 60)
    print("STEP 2: TESTING FEDERATED LEARNING TRAINING PROCESS")
    print("=" * 60)

    print("[*] Launching Federated Learning Pipeline (FedAvg across 3 hospitals)...")
    fed_res = run_federated_pipeline()

    print(f"[*] Training Status   : {fed_res.get('status')}")
    print(f"[*] Total Records     : {fed_res.get('total_dataset_records')}")
    
    global_metrics = fed_res.get('global_model', {}).get('metrics', {})
    print(f"[*] Global Accuracy   : {global_metrics.get('accuracy')}%")
    print(f"[*] Global Precision  : {global_metrics.get('precision')}%")
    print(f"[*] Global Recall     : {global_metrics.get('recall')}%")
    print(f"[*] Global F1 Score   : {global_metrics.get('f1_score')}%")

    assert global_metrics.get('accuracy', 0) > 85.0, "Model accuracy is unexpectedly low"
    print("[+] SUCCESS: Federated Learning training completed successfully with high accuracy!")


def test_risk_analysis_pipeline():
    print("\n" + "=" * 60)
    print("STEP 3: TESTING RISK ANALYSIS & CLINICAL PREDICTIONS")
    print("=" * 60)

    # Patient 1: High Risk Diabetes
    p1_personal = {'patient_name': 'Rahul Sharma', 'city': 'Mumbai', 'age': '54', 'gender': 'Male'}
    p1_health = {
        'weight': '95', 'height': '170',
        'glucose': '190', 'blood_pressure': '95',
        'pregnancies': '0', 'insulin': '180', 'skin_thickness': '35', 'dpf': '0.85'
    }
    r1 = analyze_disease_risk('Diabetes', p1_personal, p1_health)
    print(f"[*] Patient 1 (Diabetes): {p1_personal['patient_name']} -> Risk: {r1.get('predicted_category')} ({r1.get('probability')}%) | BMI: {r1.get('inputs', {}).get('BMI')}")
    assert r1.get('predicted_category') == 'High Risk'
    assert r1.get('success') is True

    # Patient 2: Low Risk Diabetes
    p2_personal = {'patient_name': 'Ananya Verma', 'city': 'Bangalore', 'age': '24', 'gender': 'Female'}
    p2_health = {
        'weight': '52', 'height': '165',
        'glucose': '88', 'blood_pressure': '70',
        'pregnancies': '0', 'insulin': '65', 'skin_thickness': '18', 'dpf': '0.15'
    }
    r2 = analyze_disease_risk('Diabetes', p2_personal, p2_health)
    print(f"[*] Patient 2 (Diabetes): {p2_personal['patient_name']} -> Risk: {r2.get('predicted_category')} ({r2.get('probability')}%) | BMI: {r2.get('inputs', {}).get('BMI')}")
    assert r2.get('predicted_category') == 'Low Risk'

    # Patient 3: Heart Disease
    p3_personal = {'patient_name': 'Vikram Malhotra', 'city': 'Delhi', 'age': '62', 'gender': 'Male'}
    p3_health = {
        'weight': '85', 'height': '172', 'trestbps': '155', 'chol': '290',
        'cp': '2', 'thalach': '110', 'exang': '1'
    }
    r3 = analyze_disease_risk('Heart Disease', p3_personal, p3_health)
    print(f"[*] Patient 3 (Heart Disease): {p3_personal['patient_name']} -> Risk: {r3.get('predicted_category')} ({r3.get('probability')}%)")
    assert r3.get('success') is True

    # Patient 4: Hypertension
    p4_personal = {'patient_name': 'Meera Patel', 'city': 'Ahmedabad', 'age': '52', 'gender': 'Female'}
    p4_health = {
        'weight': '78', 'height': '160', 'systolic_bp': '165', 'diastolic_bp': '102'
    }
    r4 = analyze_disease_risk('Hypertension', p4_personal, p4_health)
    print(f"[*] Patient 4 (Hypertension): {p4_personal['patient_name']} -> Risk: {r4.get('predicted_category')} ({r4.get('probability')}%)")
    assert r4.get('success') is True
    assert r4.get('predicted_category') == 'High Risk'

    # Patient 5: Asthma
    p5_personal = {'patient_name': 'Kavita Singh', 'city': 'Pune', 'age': '22', 'gender': 'Female'}
    p5_health = {
        'weight': '52', 'height': '158', 'wheezing': '1', 'shortness_of_breath': '1', 'cough': '1'
    }
    r5 = analyze_disease_risk('Asthma', p5_personal, p5_health)
    print(f"[*] Patient 5 (Asthma): {p5_personal['patient_name']} -> Risk: {r5.get('predicted_category')} ({r5.get('probability')}%)")
    assert r5.get('success') is True

    print("[+] SUCCESS: Risk analysis working perfectly across all 4 disease models!")


def test_database_persistence():
    print("\n" + "=" * 60)
    print("STEP 4: TESTING SQLITE DATABASE PERSISTENCE")
    print("=" * 60)

    init_db()
    count_before = get_total_assessments_count()
    print(f"[*] Total Saved Patient Records Before Test: {count_before}")

    # Generate assessment using actual disease service
    patient_info = {'patient_name': 'Sanjay Joshi', 'city': 'Chennai', 'age': '48', 'gender': 'Male'}
    health_info = {
        'weight': '85', 'height': '173', 'glucose': '172', 'blood_pressure': '88',
        'pregnancies': '0', 'insulin': '140', 'skin_thickness': '28', 'dpf': '0.62'
    }
    assessment_result = analyze_disease_risk('Diabetes', patient_info, health_info)
    assert assessment_result['success'] is True

    # Save to SQLite
    rec_id = save_assessment(assessment_result)
    print(f"[*] Assessment saved with Record ID: {rec_id}")

    count_after = get_total_assessments_count()
    assert count_after == count_before + 1
    print(f"[*] Total Saved Patient Records After Test: {count_after}")

    recent = get_recent_assessments(limit=1)
    assert len(recent) > 0
    assert recent[0]['record_id'] == rec_id
    print(f"[+] SUCCESS: Verified database persistence for record {rec_id}!")


def test_flask_web_routes():
    print("\n" + "=" * 60)
    print("STEP 5: TESTING FLASK WEB ROUTES & UI ENDPOINTS")
    print("=" * 60)

    client = app.test_client()

    routes = [
        ('/', 'Dashboard'),
        ('/hadoop', 'Hadoop HDFS Storage'),
        ('/risk-analysis', 'Risk Analysis'),
        ('/patient-records', 'Patient Records History'),
        ('/api/hadoop-test', 'Hadoop Ping API')
    ]

    for route, name in routes:
        res = client.get(route)
        print(f"[*] Testing GET {route.ljust(18)} ({name}): HTTP {res.status_code}")
        assert res.status_code == 200, f"Route {route} failed with {res.status_code}"

    # Test Web Upload via POST /hadoop
    upload_post = client.post('/hadoop', data={'action': 'upload'}, follow_redirects=True)
    print(f"[*] Testing POST /hadoop (Upload Datasets Button): HTTP {upload_post.status_code}")
    assert upload_post.status_code == 200

    print("[+] SUCCESS: All web pages and UI endpoints are 100% operational!")


if __name__ == '__main__':
    print("\n" + "#" * 60)
    print("  HEALTHCARE ANALYTICS & HADOOP END-TO-END PIPELINE TEST")
    print("#" * 60)

    try:
        test_hadoop_pipeline()
        test_federated_training_pipeline()
        test_risk_analysis_pipeline()
        test_database_persistence()
        test_flask_web_routes()

        print("\n" + "#" * 60)
        print("  ALL 5 TEST PHASES PASSED WITH 100% SUCCESS!")
        print("  Hadoop Upload -> FedAvg Train -> Risk Analysis -> DB -> Web UI")
        print("#" * 60 + "\n")
    except Exception as e:
        print(f"\n[!] TEST FAILED WITH ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
