@echo off
title Healthcare Analytics - Privacy Preserving Web App
color 0b

echo ======================================================================
echo    Starting Healthcare Analytics Web Application
echo ======================================================================
echo.
echo Local Laptop Access:   http://127.0.0.1:5000
echo Mobile Phone Access:   http://192.168.29.143:5000
echo.
echo Press Ctrl + C to stop the server anytime.
echo ======================================================================
echo.

python app.py
pause
