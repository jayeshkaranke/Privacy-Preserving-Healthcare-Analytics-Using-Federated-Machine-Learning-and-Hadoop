import os
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import joblib

# Import the helper that loads the combined dataset from WebHDFS (with local fallback)
from .hdfs_data_service import load_training_data_from_hdfs

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MODELS_DIR = os.path.join(BASE_DIR, "models")
GLOBAL_MODEL_PATH = os.path.join(MODELS_DIR, "global_diabetes_model.joblib")
SCALER_PATH = os.path.join(MODELS_DIR, "scaler.joblib")

def retrain_global_model_from_hdfs():
    """Load the merged hospital dataset from HDFS, train a logistic‑regression
    model, and replace the existing global model used by the Flask app.

    Returns
    -------
    dict
        A short status report containing success flag, a message and the
        training accuracy (percentage).
    """
    # Load the data – the helper will download from WebHDFS if the file is present,
    # otherwise it falls back to the local CSV used during development.
    df = load_training_data_from_hdfs()

    # Expected feature / target columns (same as in the original training script).
    feature_cols = [
        "Pregnancies",
        "Glucose",
        "BloodPressure",
        "SkinThickness",
        "Insulin",
        "BMI",
        "DiabetesPedigreeFunction",
        "Age",
    ]
    target_col = "Outcome"

    missing = set(feature_cols + [target_col]) - set(df.columns)
    if missing:
        raise ValueError(f"Combined HDFS dataset missing required columns: {missing}")

    X = df[feature_cols]
    y = df[target_col]

    # Standardise the features – this mirrors the original pipeline.
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Train a logistic regression model (same hyper‑parameters as the original).
    model = LogisticRegression(max_iter=1000, random_state=42)
    model.fit(X_scaled, y)

    # Simple training‑set accuracy for quick verification.
    accuracy = (model.predict(X_scaled) == y).mean() * 100

    # Persist the scaler and model so the Flask routes can load them.
    os.makedirs(MODELS_DIR, exist_ok=True)
    joblib.dump(scaler, SCALER_PATH)
    joblib.dump(model, GLOBAL_MODEL_PATH)

    return {
        "success": True,
        "message": f"Retrained global model from HDFS (records={len(df)}).",
        "accuracy_percent": round(float(accuracy), 2),
    }
