import os
import hashlib
import io
import pandas as pd
import requests
from .hadoop_service import get_hadoop_config

# Columns considered PII that need to be removed or hashed
PII_COLUMNS = ['patient_name', 'phone', 'email', 'exact_address', 'patient_id']

def _hash_value(value: str) -> str:
    """Return a deterministic SHA-256 hash for a given string value."""
    return hashlib.sha256(value.encode('utf-8')).hexdigest()

def deidentify_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of *df* with PII columns removed or hashed.

    - Columns listed in ``PII_COLUMNS`` are dropped if present.
    - If a column named ``patient_id`` exists, it is replaced by a hashed version
      to retain a unique identifier without exposing the original ID.
    """
    df_clean = df.copy()
    for col in PII_COLUMNS:
        if col in df_clean.columns:
            if col == 'patient_id':
                df_clean[col] = df_clean[col].astype(str).apply(_hash_value)
            else:
                df_clean.drop(columns=[col], inplace=True)
    return df_clean

def upload_to_hdfs(df: pd.DataFrame, hdfs_path: str, config: dict = None) -> dict:
    """Upload a pandas DataFrame to WebHDFS.

    Parameters
    ----------
    df: pandas.DataFrame
        Data to upload.
    hdfs_path: str
        Absolute HDFS path (e.g. ``/user/hadoop/health_data/shared_hospital_records.csv``).
    config: dict, optional
        Hadoop config dict with ``host``, ``port`` and ``user``. If omitted, the
        default config from :func:`hadoop_service.get_hadoop_config` is used.

    Returns
    -------
    dict
        ``{'success': True, 'message': ...}`` on success, otherwise ``{'success': False, 'message': ...}``.
    """
    cfg = config or get_hadoop_config()
    host = cfg.get('host', 'localhost')
    port = cfg.get('port', 9870)
    user = cfg.get('user', 'hadoop')
    init_url = f"http://{host}:{port}/webhdfs/v1{hdfs_path}?op=CREATE&overwrite=true&user.name={user}"
    try:
        init_resp = requests.put(init_url, allow_redirects=False, timeout=5)
        if init_resp.status_code != 307:
            return {'success': False, 'message': f'Failed to initiate create: HTTP {init_resp.status_code}'}
        redirect_url = init_resp.headers['Location']
        csv_bytes = df.to_csv(index=False).encode('utf-8')
        upload_resp = requests.put(redirect_url, data=csv_bytes, headers={'Content-Type': 'application/octet-stream'}, timeout=10)
        if upload_resp.status_code in (200, 201):
            return {'success': True, 'message': f'Dataset uploaded to {hdfs_path}'}
        else:
            return {'success': False, 'message': f'Upload failed: HTTP {upload_resp.status_code}'}
    except Exception as e:
        return {'success': False, 'message': str(e)}

def load_training_data_from_hdfs(hdfs_path: str = '/user/hadoop/health_data/shared_hospital_records.csv', config: dict = None) -> pd.DataFrame:
    """Read a CSV dataset from WebHDFS and return it as a pandas DataFrame.

    Falls back to local hospital CSVs if the NameNode is unreachable.
    """
    cfg = config or get_hadoop_config()
    host = cfg.get('host', 'localhost')
    port = cfg.get('port', 9870)
    user = cfg.get('user', 'hadoop')
    open_url = f"http://{host}:{port}/webhdfs/v1{hdfs_path}?op=OPEN&user.name={user}"
    try:
        resp = requests.get(open_url, timeout=5)
        if resp.status_code == 200:
            return pd.read_csv(io.StringIO(resp.text))
        else:
            raise RuntimeError(f'WebHDFS returned {resp.status_code}')
    except Exception:
        # Local fallback – concatenate the three hospital CSVs
        from .data_service import HOSPITAL_METADATA
        frames = []
        for meta in HOSPITAL_METADATA.values():
            path = meta['file']
            if os.path.exists(path):
                frames.append(pd.read_csv(path))
        if frames:
            return pd.concat(frames, ignore_index=True)
        else:
            raise FileNotFoundError('No local hospital datasets available for fallback.')
