"""
hadoop_service.py - Hadoop HDFS Storage Integration Service.
Provides connectivity to Hadoop HDFS via WebHDFS REST API, directory provisioning
for distributed hospitals, and automated graceful fallback to Local Demonstration Mode
when a live Hadoop cluster is not active on Windows.
"""

import os
import json
import requests
from datetime import datetime

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DATA_DIR = os.path.join(BASE_DIR, 'data')
CONFIG_FILE = os.path.join(BASE_DIR, 'models', 'hadoop_config.json')

# Default Hadoop settings
DEFAULT_CONFIG = {
    'host': 'localhost',
    'port': 9870,  # Standard WebHDFS port for Hadoop 3.x (use 50070 for Hadoop 2.x)
    'user': 'hadoop',
    'base_hdfs_path': '/healthcare_dfs'
}


def get_hadoop_config():
    """Loads Hadoop config or returns defaults."""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    return DEFAULT_CONFIG.copy()


def save_hadoop_config(config):
    """Saves updated Hadoop configuration."""
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)


def check_hadoop_connection(host=None, port=None):
    """
    Pings WebHDFS endpoint. Returns dict with status, is_connected, message.
    """
    cfg = get_hadoop_config()
    target_host = host or cfg.get('host', 'localhost')
    target_port = port or cfg.get('port', 9870)

    url = f"http://{target_host}:{target_port}/webhdfs/v1/?op=LISTSTATUS"
    try:
        response = requests.get(url, timeout=2.0)
        if response.status_code in [200, 401, 403]:
            return {
                'is_connected': True,
                'status': 'CONNECTED',
                'badge': 'bg-success',
                'mode': 'Live Hadoop HDFS Cluster',
                'message': f"Successfully connected to WebHDFS NameNode at {target_host}:{target_port}",
                'endpoint': url
            }
        else:
            return {
                'is_connected': False,
                'status': 'LOCAL_DEMO',
                'badge': 'bg-warning text-dark',
                'mode': 'Local Demonstration Mode (Hadoop Offline)',
                'message': f"NameNode responded with HTTP {response.status_code}. Using local demonstration storage.",
                'endpoint': url
            }
    except Exception as e:
        return {
            'is_connected': False,
            'status': 'LOCAL_DEMO',
            'badge': 'bg-warning text-dark',
            'mode': 'Local Demonstration Mode (Hadoop Inactive)',
            'message': f"Hadoop NameNode not reachable at {target_host}:{target_port}. Operating safely in Local Demonstration Mode.",
            'endpoint': url,
            'error_detail': str(e)
        }


def get_hdfs_storage_status():
    """
    Returns current storage overview for Hospital A, B, C datasets and Global Model.
    """
    cfg = get_hadoop_config()
    conn = check_hadoop_connection(cfg['host'], cfg['port'])
    base_hdfs = cfg.get('base_hdfs_path', '/healthcare_dfs')

    hospitals_storage = [
        {
            'hospital_id': 'Hospital_A',
            'hospital_name': 'Sunrise Multispeciality Hospital',
            'hdfs_dir': f"{base_hdfs}/hospital_A/",
            'hdfs_file': f"{base_hdfs}/hospital_A/hospital_A.csv",
            'local_file': os.path.join(DATA_DIR, 'hospital_A.csv'),
            'local_size_bytes': os.path.getsize(os.path.join(DATA_DIR, 'hospital_A.csv')) if os.path.exists(os.path.join(DATA_DIR, 'hospital_A.csv')) else 0,
            'replication_factor': 3 if conn['is_connected'] else 1,
            'block_size_mb': 128
        },
        {
            'hospital_id': 'Hospital_B',
            'hospital_name': 'CityCare Medical Centre',
            'hdfs_dir': f"{base_hdfs}/hospital_B/",
            'hdfs_file': f"{base_hdfs}/hospital_B/hospital_B.csv",
            'local_file': os.path.join(DATA_DIR, 'hospital_B.csv'),
            'local_size_bytes': os.path.getsize(os.path.join(DATA_DIR, 'hospital_B.csv')) if os.path.exists(os.path.join(DATA_DIR, 'hospital_B.csv')) else 0,
            'replication_factor': 3 if conn['is_connected'] else 1,
            'block_size_mb': 128
        },
        {
            'hospital_id': 'Hospital_C',
            'hospital_name': 'GreenLife Hospital',
            'hdfs_dir': f"{base_hdfs}/hospital_C/",
            'hdfs_file': f"{base_hdfs}/hospital_C/hospital_C.csv",
            'local_file': os.path.join(DATA_DIR, 'hospital_C.csv'),
            'local_size_bytes': os.path.getsize(os.path.join(DATA_DIR, 'hospital_C.csv')) if os.path.exists(os.path.join(DATA_DIR, 'hospital_C.csv')) else 0,
            'replication_factor': 3 if conn['is_connected'] else 1,
            'block_size_mb': 128
        }
    ]

    return {
        'connection': conn,
        'config': cfg,
        'storage_items': hospitals_storage,
        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }


def upload_datasets_to_hdfs(host=None, port=None):
    """
    Attempts to upload hospital datasets to live WebHDFS.
    If Hadoop is offline, records simulated demonstration upload and returns informative message.
    """
    cfg = get_hadoop_config()
    target_host = host or cfg.get('host', 'localhost')
    target_port = port or cfg.get('port', 9870)
    user = cfg.get('user', 'hadoop')
    base_path = cfg.get('base_hdfs_path', '/healthcare_dfs')

    conn = check_hadoop_connection(target_host, target_port)

    datasets = [
        ('hospital_A.csv', f"{base_path}/hospital_A/hospital_A.csv"),
        ('hospital_B.csv', f"{base_path}/hospital_B/hospital_B.csv"),
        ('hospital_C.csv', f"{base_path}/hospital_C/hospital_C.csv"),
    ]

    results = []

    if conn['is_connected']:
        # Real WebHDFS upload
        for filename, hdfs_path in datasets:
            local_path = os.path.join(DATA_DIR, filename)
            if not os.path.exists(local_path):
                results.append({'file': filename, 'status': 'Error', 'message': 'Local file not found'})
                continue
            try:
                # Step 1: PUT request with op=CREATE to get redirect location
                init_url = f"http://{target_host}:{target_port}/webhdfs/v1{hdfs_path}?op=CREATE&overwrite=true&user.name={user}"
                res = requests.put(init_url, allow_redirects=False, timeout=3.0)

                if res.status_code == 307:
                    # Step 2: Stream content to redirect URL
                    redirect_url = res.headers['Location']
                    with open(local_path, 'rb') as f:
                        upload_res = requests.put(redirect_url, data=f, headers={'Content-Type': 'application/octet-stream'}, timeout=10.0)
                    if upload_res.status_code in [200, 201]:
                        results.append({'file': filename, 'status': 'Uploaded to HDFS', 'hdfs_path': hdfs_path})
                    else:
                        results.append({'file': filename, 'status': 'Failed', 'message': f"HTTP {upload_res.status_code}"})
                else:
                    results.append({'file': filename, 'status': 'Failed', 'message': f"NameNode responded with {res.status_code}"})
            except Exception as e:
                results.append({'file': filename, 'status': 'Failed', 'message': str(e)})

        return {
            'mode': 'Live Hadoop HDFS',
            'success': True,
            'message': 'Datasets successfully transferred to Hadoop Distributed File System cluster.',
            'details': results
        }
    else:
        # Local demonstration mode fallback
        for filename, hdfs_path in datasets:
            local_path = os.path.join(DATA_DIR, filename)
            exists = os.path.exists(local_path)
            size = os.path.getsize(local_path) if exists else 0
            results.append({
                'file': filename,
                'status': 'Mapped in Local Demo Mode',
                'simulated_hdfs_path': f"hdfs://{target_host}:9000{hdfs_path}",
                'local_path': local_path,
                'size_bytes': size
            })

        return {
            'mode': 'Local Demonstration Mode',
            'success': False,
            'is_local_demo': True,
            'message': 'Hadoop cluster is offline. Simulated HDFS directory mapping completed in Local Demonstration Mode. Raw hospital datasets remain securely isolated in local files.',
            'details': results
        }
