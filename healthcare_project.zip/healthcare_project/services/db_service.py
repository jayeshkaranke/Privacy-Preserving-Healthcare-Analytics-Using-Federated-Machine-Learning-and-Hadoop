"""
db_service.py - SQLite Database Service for Patient Records.
Handles persistent storage, retrieval, searching, and filtering of patient clinical assessments.
"""

import os
import sqlite3
import json
from datetime import datetime

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DB_PATH = os.path.join(BASE_DIR, 'data', 'patient_records.db')


def get_db_connection():
    """Returns a connection to the SQLite database with row factory enabled."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initializes the database schema and seeds initial sample records if empty."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS patient_assessments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            record_id TEXT UNIQUE NOT NULL,
            patient_name TEXT NOT NULL,
            city TEXT NOT NULL,
            age INTEGER NOT NULL,
            gender TEXT NOT NULL,
            disease TEXT NOT NULL,
            assessment_date TEXT NOT NULL,
            inputs_json TEXT NOT NULL,
            predicted_category TEXT NOT NULL,
            probability REAL,
            explanation TEXT,
            recommendations_json TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()

    # Check if empty, seed initial sample records for immediate demo
    cursor.execute('SELECT COUNT(*) AS cnt FROM patient_assessments')
    count = cursor.fetchone()['cnt']

    if count == 0:
        sample_records = [
            {
                'record_id': 'REC-1001',
                'patient_name': 'Anita Sharma',
                'city': 'Mumbai',
                'age': 45,
                'gender': 'Female',
                'disease': 'Diabetes',
                'assessment_date': '2026-10-14 10:30',
                'inputs': {
                    'Glucose': 168.0,
                    'BloodPressure': 84.0,
                    'Weight': 78.0,
                    'Height': 162.0,
                    'BMI': 29.72,
                    'Insulin': 140.0,
                    'SkinThickness': 32.0,
                    'Pregnancies': 2,
                    'DiabetesPedigreeFunction': 0.65
                },
                'predicted_category': 'Moderate Risk',
                'probability': 58.45,
                'explanation': 'The model predicts an elevated probability (58.45%) of the positive class based on plasma glucose (168 mg/dL) and elevated BMI (29.72 kg/m²).',
                'recommendations': [
                    'Schedule a comprehensive fasting glucose and HbA1c test with a physician.',
                    'Adopt a low-glycemic Mediterranean or balanced dietary regimen.',
                    'Incorporate 30 minutes of moderate aerobic activity 5 days a week.',
                    'Monitor resting blood pressure periodically.'
                ]
            },
            {
                'record_id': 'REC-1002',
                'patient_name': 'Rajesh Patel',
                'city': 'Ahmedabad',
                'age': 32,
                'gender': 'Male',
                'disease': 'Diabetes',
                'assessment_date': '2026-10-14 14:15',
                'inputs': {
                    'Glucose': 95.0,
                    'BloodPressure': 72.0,
                    'Weight': 68.0,
                    'Height': 175.0,
                    'BMI': 22.20,
                    'Insulin': 85.0,
                    'SkinThickness': 20.0,
                    'Pregnancies': 0,
                    'DiabetesPedigreeFunction': 0.24
                },
                'predicted_category': 'Low Risk',
                'probability': 12.80,
                'explanation': 'The model predicts a lower probability (12.80%) of the positive class. All major physiological indicators are within normal healthy baselines.',
                'recommendations': [
                    'Maintain current active lifestyle and nutritious dietary habits.',
                    'Continue routine annual preventative wellness checkups.',
                    'Stay well hydrated and maintain consistent sleep hygiene.'
                ]
            },
            {
                'record_id': 'REC-1003',
                'patient_name': 'Meera Kulkarni',
                'city': 'Pune',
                'age': 54,
                'gender': 'Female',
                'disease': 'Diabetes',
                'assessment_date': '2026-10-15 09:45',
                'inputs': {
                    'Glucose': 185.0,
                    'BloodPressure': 90.0,
                    'Weight': 86.0,
                    'Height': 158.0,
                    'BMI': 34.45,
                    'Insulin': 210.0,
                    'SkinThickness': 38.0,
                    'Pregnancies': 4,
                    'DiabetesPedigreeFunction': 0.82
                },
                'predicted_category': 'High Risk',
                'probability': 78.90,
                'explanation': 'The model predicts a higher probability (78.90%) of the positive class due to combination of high plasma glucose (185 mg/dL), Class I obesity BMI (34.45 kg/m²), and age > 50.',
                'recommendations': [
                    'Consult a specialist diabetologist or clinical endocrinologist promptly.',
                    'Undergo laboratory evaluation including HbA1c, lipid panel, and renal function.',
                    'Engage a certified clinical dietitian for structured meal planning.',
                    'Perform daily blood glucose self-monitoring as recommended by a doctor.'
                ]
            }
        ]

        for r in sample_records:
            cursor.execute('''
                INSERT INTO patient_assessments (
                    record_id, patient_name, city, age, gender, disease,
                    assessment_date, inputs_json, predicted_category, probability,
                    explanation, recommendations_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                r['record_id'],
                r['patient_name'],
                r['city'],
                r['age'],
                r['gender'],
                r['disease'],
                r['assessment_date'],
                json.dumps(r['inputs']),
                r['predicted_category'],
                r['probability'],
                r['explanation'],
                json.dumps(r['recommendations'])
            ))
        conn.commit()

    conn.close()


def generate_next_record_id():
    """Generates sequential, user-friendly record IDs like REC-1004."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT MAX(id) AS max_id FROM patient_assessments')
    row = cursor.fetchone()
    conn.close()
    next_num = 1001 if not row or not row['max_id'] else row['max_id'] + 1001
    return f"REC-{next_num}"


def save_assessment(patient_data):
    """
    Saves a newly conducted patient assessment to the database.
    Returns the generated record_id.
    """
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()

    record_id = generate_next_record_id()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")

    inputs_json = json.dumps(patient_data.get('inputs', {}))
    recs_json = json.dumps(patient_data.get('recommendations', []))

    cursor.execute('''
        INSERT INTO patient_assessments (
            record_id, patient_name, city, age, gender, disease,
            assessment_date, inputs_json, predicted_category, probability,
            explanation, recommendations_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        record_id,
        patient_data['patient_name'].strip(),
        patient_data['city'].strip(),
        int(patient_data['age']),
        patient_data.get('gender', 'Not Specified'),
        patient_data.get('disease', 'Diabetes'),
        now_str,
        inputs_json,
        patient_data.get('predicted_category', 'Assessed'),
        float(patient_data.get('probability', 0.0)),
        patient_data.get('explanation', ''),
        recs_json
    ))
    conn.commit()
    conn.close()
    return record_id


def get_all_assessments(search=None, disease_filter=None, sort_order='desc'):
    """
    Retrieves all patient assessments with optional search by name/city,
    disease filtering, and sorting by assessment date.
    """
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()

    query = 'SELECT * FROM patient_assessments WHERE 1=1'
    params = []

    if search:
        search_term = f"%{search.strip()}%"
        query += ' AND (patient_name LIKE ? OR city LIKE ? OR record_id LIKE ?)'
        params.extend([search_term, search_term, search_term])

    if disease_filter and disease_filter.lower() != 'all':
        query += ' AND disease = ?'
        params.append(disease_filter)

    order = 'DESC' if sort_order.lower() == 'desc' else 'ASC'
    query += f' ORDER BY id {order}'

    cursor.execute(query, params)
    rows = cursor.fetchall()

    results = []
    for row in rows:
        r_dict = dict(row)
        try:
            r_dict['inputs'] = json.loads(r_dict['inputs_json'])
        except Exception:
            r_dict['inputs'] = {}
        try:
            r_dict['recommendations'] = json.loads(r_dict['recommendations_json'])
        except Exception:
            r_dict['recommendations'] = []
        results.append(r_dict)

    conn.close()
    return results


def get_assessment_by_id(record_id):
    """
    Retrieves the original saved assessment details without re-running prediction.
    """
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM patient_assessments WHERE record_id = ? OR id = ?', (record_id, record_id))
    row = cursor.fetchone()
    conn.close()

    if not row:
        return None

    r_dict = dict(row)
    try:
        r_dict['inputs'] = json.loads(r_dict['inputs_json'])
    except Exception:
        r_dict['inputs'] = {}
    try:
        r_dict['recommendations'] = json.loads(r_dict['recommendations_json'])
    except Exception:
        r_dict['recommendations'] = []
    return r_dict


def get_recent_assessments(limit=5):
    """Retrieves recent assessments for dashboard display."""
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM patient_assessments ORDER BY id DESC LIMIT ?', (limit,))
    rows = cursor.fetchall()
    conn.close()

    results = []
    for row in rows:
        r_dict = dict(row)
        try:
            r_dict['inputs'] = json.loads(r_dict['inputs_json'])
        except Exception:
            r_dict['inputs'] = {}
        try:
            r_dict['recommendations'] = json.loads(r_dict['recommendations_json'])
        except Exception:
            r_dict['recommendations'] = []
        results.append(r_dict)
    return results


def get_total_assessments_count():
    """Returns total count of saved patient assessments."""
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) AS total FROM patient_assessments')
    row = cursor.fetchone()
    conn.close()
    return row['total'] if row else 0
