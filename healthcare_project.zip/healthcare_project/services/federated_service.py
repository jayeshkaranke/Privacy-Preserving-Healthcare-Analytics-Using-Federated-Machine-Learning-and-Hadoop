"""
federated_service.py - Core Federated Learning Engine.
Simulates decentralized hospital nodes, trains local Logistic Regression models,
extracts parameter vectors (weights & biases), performs FedAvg parameter aggregation,
evaluates global performance against local models, and provides diabetes risk inference.
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

from services.data_service import (
    load_hospital_data,
    load_test_data,
    FEATURE_COLUMNS,
    HOSPITAL_METADATA,
    prepare_and_partition_data
)

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
MODELS_DIR = os.path.join(BASE_DIR, 'models')

GLOBAL_MODEL_PATH = os.path.join(MODELS_DIR, 'global_diabetes_model.joblib')
SCALER_PATH = os.path.join(MODELS_DIR, 'scaler.joblib')
RESULTS_CACHE_PATH = os.path.join(MODELS_DIR, 'federated_results.json')


def get_or_fit_scaler():
    """
    Returns a consistent StandardScaler across all features.
    If cached, loads it; otherwise fits on training partitions and caches.
    """
    os.makedirs(MODELS_DIR, exist_ok=True)
    if os.path.exists(SCALER_PATH):
        return joblib.load(SCALER_PATH)

    # Combine hospital training sets only to derive standard feature scaling
    X_list = []
    for h_key in HOSPITAL_METADATA.keys():
        X, _ = load_hospital_data(h_key)
        X_list.append(X)
    X_train_combined = pd.concat(X_list, axis=0)

    scaler = StandardScaler()
    scaler.fit(X_train_combined)
    joblib.dump(scaler, SCALER_PATH)
    return scaler


def train_hospital_local_model(hospital_key, scaler):
    """
    Simulates training a local model at an individual hospital.
    The hospital trains Logistic Regression ONLY on its private dataset.
    Returns:
        parameters: dict with 'weights', 'bias', 'sample_count'
        metrics: evaluation metrics on common holdout test set
    """
    X_train, y_train = load_hospital_data(hospital_key)
    X_test, y_test = load_test_data()

    X_train_scaled = scaler.transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    model = LogisticRegression(max_iter=1000, random_state=42, solver='lbfgs')
    model.fit(X_train_scaled, y_train)

    y_pred = model.predict(X_test_scaled)
    cm = confusion_matrix(y_test, y_pred)

    metrics = {
        'accuracy': round(float(accuracy_score(y_test, y_pred)) * 100, 2),
        'precision': round(float(precision_score(y_test, y_pred, zero_division=0)) * 100, 2),
        'recall': round(float(recall_score(y_test, y_pred, zero_division=0)) * 100, 2),
        'f1_score': round(float(f1_score(y_test, y_pred, zero_division=0)) * 100, 2),
        'confusion_matrix': cm.tolist(),
        'sample_count': int(len(X_train))
    }

    parameters = {
        'weights': model.coef_[0].tolist(),
        'bias': float(model.intercept_[0]),
        'sample_count': int(len(X_train))
    }

    return model, parameters, metrics


def aggregate_federated_parameters(local_parameters_dict):
    """
    Federated Averaging (FedAvg):
    Combines local model parameters using weighted averaging based on hospital sample count.
    Formula:
        W_global = sum( (n_k / N) * W_k )
        b_global = sum( (n_k / N) * b_k )
    Raw patient records are NEVER shared or aggregated.
    """
    total_samples = sum(p['sample_count'] for p in local_parameters_dict.values())
    if total_samples == 0:
        raise ValueError("Total sample count across hospitals is 0.")

    num_features = len(FEATURE_COLUMNS)
    global_weights = np.zeros(num_features)
    global_bias = 0.0

    weight_contributions = {}

    for h_key, params in local_parameters_dict.items():
        weight_ratio = params['sample_count'] / total_samples
        weight_contributions[h_key] = round(float(weight_ratio) * 100, 2)
        local_w = np.array(params['weights'])
        local_b = params['bias']

        global_weights += weight_ratio * local_w
        global_bias += weight_ratio * local_b

    return {
        'weights': global_weights.tolist(),
        'bias': float(global_bias),
        'total_samples': total_samples,
        'contributions': weight_contributions
    }


def run_federated_pipeline():
    """
    Orchestrates the entire federated learning simulation:
    1. Trains Local Model at Hospital A
    2. Trains Local Model at Hospital B
    3. Trains Local Model at Hospital C
    4. Extracts parameters (weights & bias) from each
    5. Centrally aggregates parameters via FedAvg
    6. Constructs and saves Global Model
    7. Evaluates Global Model on holdout test set
    8. Caches results
    """
    prepare_and_partition_data()
    scaler = get_or_fit_scaler()

    local_models = {}
    local_params = {}
    local_metrics = {}

    # Step 1-3: Local hospital training
    for h_key in ['Hospital_A', 'Hospital_B', 'Hospital_C']:
        model, params, metrics = train_hospital_local_model(h_key, scaler)
        local_models[h_key] = model
        local_params[h_key] = params
        local_metrics[h_key] = metrics

    # Step 4-5: Federated Parameter Aggregation
    global_params = aggregate_federated_parameters(local_params)

    # Step 6: Construct Global Logistic Regression model from aggregated weights
    global_model = LogisticRegression(max_iter=1000, random_state=42)
    global_model.classes_ = np.array([0, 1])
    global_model.coef_ = np.array([global_params['weights']])
    global_model.intercept_ = np.array([global_params['bias']])

    # Step 7: Evaluate Global Model on holdout test data
    X_test, y_test = load_test_data()
    X_test_scaled = scaler.transform(X_test)
    y_pred = global_model.predict(X_test_scaled)
    y_prob = global_model.predict_proba(X_test_scaled)[:, 1]

    cm = confusion_matrix(y_test, y_pred)
    global_metrics = {
        'accuracy': round(float(accuracy_score(y_test, y_pred)) * 100, 2),
        'precision': round(float(precision_score(y_test, y_pred, zero_division=0)) * 100, 2),
        'recall': round(float(recall_score(y_test, y_pred, zero_division=0)) * 100, 2),
        'f1_score': round(float(f1_score(y_test, y_pred, zero_division=0)) * 100, 2),
        'confusion_matrix': cm.tolist(),
        'test_samples': int(len(X_test))
    }

    # Save artifacts
    os.makedirs(MODELS_DIR, exist_ok=True)
    joblib.dump(global_model, GLOBAL_MODEL_PATH)

    # Feature importance mapping for global model
    feature_importance = []
    for col, w in zip(FEATURE_COLUMNS, global_params['weights']):
        feature_importance.append({
            'feature': col,
            'weight': round(float(w), 4),
            'impact': 'Increases Risk' if w > 0 else 'Protective / Lowers Risk'
        })
    # Sort by absolute weight magnitude
    feature_importance.sort(key=lambda x: abs(x['weight']), reverse=True)

    results = {
        'status': 'success',
        'is_trained': True,
        'local_models': {
            'Hospital_A': {
                'name': HOSPITAL_METADATA['Hospital_A']['name'],
                'metrics': local_metrics['Hospital_A'],
                'parameters': local_params['Hospital_A']
            },
            'Hospital_B': {
                'name': HOSPITAL_METADATA['Hospital_B']['name'],
                'metrics': local_metrics['Hospital_B'],
                'parameters': local_params['Hospital_B']
            },
            'Hospital_C': {
                'name': HOSPITAL_METADATA['Hospital_C']['name'],
                'metrics': local_metrics['Hospital_C'],
                'parameters': local_params['Hospital_C']
            }
        },
        'global_model': {
            'metrics': global_metrics,
            'parameters': global_params,
            'feature_importance': feature_importance
        },
        'feature_names': FEATURE_COLUMNS
    }

    with open(RESULTS_CACHE_PATH, 'w') as f:
        json.dump(results, f, indent=2)

    return results


def get_federated_status():
    """
    Returns cached federated training results, or trains automatically if not yet run.
    """
    if os.path.exists(RESULTS_CACHE_PATH) and os.path.exists(GLOBAL_MODEL_PATH):
        try:
            with open(RESULTS_CACHE_PATH, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    # If not yet trained, run pipeline once
    return run_federated_pipeline()


def predict_diabetes_risk(input_data):
    """
    Predicts diabetes risk using the trained global federated model.
    Input: dictionary with keys from FEATURE_COLUMNS.
    Output:
        risk_probability: float %
        risk_level: 'Low Risk', 'Moderate Risk', or 'High Risk'
        prediction: 0 or 1
        key_factors: list of clinical notes
    """
    # Ensure model and scaler are available
    if not os.path.exists(GLOBAL_MODEL_PATH) or not os.path.exists(SCALER_PATH):
        run_federated_pipeline()

    global_model = joblib.load(GLOBAL_MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)

    # Validate and build dataframe
    cleaned_values = []
    for col in FEATURE_COLUMNS:
        if col not in input_data:
            raise ValueError(f"Missing required clinical feature: {col}")
        try:
            val = float(input_data[col])
        except (ValueError, TypeError):
            raise ValueError(f"Feature '{col}' must be a valid numeric value.")

        if val < 0:
            raise ValueError(f"Feature '{col}' cannot be negative.")
        cleaned_values.append(val)

    input_df = pd.DataFrame([cleaned_values], columns=FEATURE_COLUMNS)

    # Scale input
    input_scaled = scaler.transform(input_df)

    # Predict
    prob = float(global_model.predict_proba(input_scaled)[0][1])
    prob_percent = round(prob * 100, 2)
    prediction = int(global_model.predict(input_scaled)[0])

    if prob_percent < 35.0:
        risk_level = 'Low Risk'
        risk_badge = 'bg-success'
        summary_text = 'Patient profile shows low statistical likelihood of diabetes onset.'
    elif prob_percent < 65.0:
        risk_level = 'Moderate Risk'
        risk_badge = 'bg-warning text-dark'
        summary_text = 'Borderline risk detected. Lifestyle interventions and glucose monitoring advised.'
    else:
        risk_level = 'High Risk'
        risk_badge = 'bg-danger'
        summary_text = 'Elevated statistical probability of diabetes. Formal clinical diagnostic assessment strongly recommended.'

    # Clinical risk drivers analysis
    key_factors = []
    gluc = input_df['Glucose'].values[0]
    bmi = input_df['BMI'].values[0]
    age = input_df['Age'].values[0]
    bp = input_df['BloodPressure'].values[0]
    dpf = input_df['DiabetesPedigreeFunction'].values[0]

    if gluc >= 140:
        key_factors.append(f"Elevated Plasma Glucose ({gluc} mg/dL) exceeds standard pre-diabetes threshold.")
    if bmi >= 30.0:
        key_factors.append(f"Body Mass Index ({bmi} kg/m²) indicates clinical obesity, a primary risk marker.")
    elif bmi >= 25.0:
        key_factors.append(f"Body Mass Index ({bmi} kg/m²) is in the overweight range.")
    if age >= 45:
        key_factors.append(f"Age ({int(age)} years) correlates with higher metabolic resistance.")
    if bp >= 85:
        key_factors.append(f"Diastolic Blood Pressure ({bp} mm Hg) is elevated.")
    if dpf >= 0.7:
        key_factors.append(f"Diabetes Pedigree Function ({dpf}) indicates strong familial hereditary risk.")

    if not key_factors:
        key_factors.append("All primary physiological indicators fall within normal statistical baselines.")

    return {
        'prediction': prediction,
        'prediction_label': 'Positive for Diabetes Risk' if prediction == 1 else 'Negative (Low Diabetes Risk)',
        'risk_probability': prob_percent,
        'risk_level': risk_level,
        'risk_badge': risk_badge,
        'summary_text': summary_text,
        'key_factors': key_factors,
        'input_data': {col: float(input_df[col].values[0]) for col in FEATURE_COLUMNS}
    }


def assess_patient_risk(personal_info, health_measurements, disease='Diabetes'):
    """
    Comprehensive multi-disease risk assessment workflow.
    Validates personal details, auto-calculates BMI from weight/height,
    invokes the appropriate trained model, defines probability bands,
    and returns personalized recommendations and clinical explanations.
    """
    # 1. Multi-disease handling
    if disease != 'Diabetes':
        return {
            'success': False,
            'disease': disease,
            'error': f"Prediction model not available for {disease}. Currently, only the federated diabetes model is trained and active.",
            'is_model_available': False
        }

    # 2. Validate Personal Information
    patient_name = str(personal_info.get('patient_name', '')).strip()
    city = str(personal_info.get('city', '')).strip()
    gender = str(personal_info.get('gender', 'Other')).strip()

    if not patient_name:
        raise ValueError("Patient's full name is required.")
    if not city:
        raise ValueError("City name is required.")

    try:
        age = int(personal_info.get('age', 0))
    except (ValueError, TypeError):
        raise ValueError("Patient age must be a valid whole number.")
    if age < 1 or age > 120:
        raise ValueError("Patient age must be between 1 and 120 years.")

    # 3. Calculate BMI from Weight (kg) and Height (cm)
    try:
        weight_kg = float(health_measurements.get('weight', 0))
    except (ValueError, TypeError):
        raise ValueError("Weight in kilograms must be a valid number.")
    if weight_kg <= 10 or weight_kg > 300:
        raise ValueError("Weight must be between 10 kg and 300 kg.")

    try:
        height_cm = float(health_measurements.get('height', 0))
    except (ValueError, TypeError):
        raise ValueError("Height in centimetres must be a valid number.")
    if height_cm <= 40 or height_cm > 260:
        raise ValueError("Height must be between 40 cm and 260 cm.")

    # BMI = weight (kg) / (height (m))^2
    height_m = height_cm / 100.0
    bmi = round(weight_kg / (height_m ** 2), 2)

    # 4. Extract and validate diabetes clinical features
    try:
        glucose = float(health_measurements.get('glucose', 0))
    except (ValueError, TypeError):
        raise ValueError("Glucose level must be a valid numeric measurement.")
    if glucose < 30 or glucose > 400:
        raise ValueError("Glucose level must be between 30 and 400 mg/dL.")

    try:
        bp = float(health_measurements.get('blood_pressure', 0))
    except (ValueError, TypeError):
        raise ValueError("Blood pressure must be a valid numeric measurement.")
    if bp < 30 or bp > 220:
        raise ValueError("Blood pressure must be between 30 and 220 mm Hg.")

    # Optional / defaulted clinical features
    insulin = float(health_measurements.get('insulin') or 79.8)
    skin_thickness = float(health_measurements.get('skin_thickness') or 20.5)
    dpf = float(health_measurements.get('dpf') or 0.47)

    # Pregnancies (if female, else 0)
    pregnancies = 0
    if gender.lower() == 'female':
        try:
            pregnancies = int(health_measurements.get('pregnancies') or 0)
        except (ValueError, TypeError):
            pregnancies = 0

    feature_dict = {
        'Pregnancies': pregnancies,
        'Glucose': glucose,
        'BloodPressure': bp,
        'SkinThickness': skin_thickness,
        'Insulin': insulin,
        'BMI': bmi,
        'DiabetesPedigreeFunction': dpf,
        'Age': age
    }

    # 5. Run trained global federated model
    pred_res = predict_diabetes_risk(feature_dict)
    prob = pred_res['risk_probability']

    # 6. Define project-specific probability bands and understandable explanation
    if prob < 35.0:
        category = 'Low Risk'
        badge_class = 'bg-success'
        explanation = f"The model predicts a lower probability ({prob}%) of the positive class. In this academic screening system, 'Low Risk' is defined as an estimated probability below 35% (a project-specific screening band, not a universal medical threshold). Most physiological measurements are aligned with normal non-diabetic baselines."
        recommendations = [
            "Maintain a balanced, nutrient-dense diet emphasizing whole grains, vegetables, and lean proteins.",
            "Engage in regular physical activity (such as 150 minutes of moderate aerobic exercise per week).",
            "Continue routine annual preventative health checkups with a certified physician.",
            "Stay adequately hydrated and ensure consistent, quality sleep."
        ]
    elif prob <= 65.0:
        category = 'Moderate Risk'
        badge_class = 'bg-warning text-dark'
        explanation = f"The model predicts a moderate / intermediate probability ({prob}%) of the positive class. In this project, 'Moderate Risk' corresponds to an estimated probability between 35% and 65%. While not a clinical diagnosis, one or more metabolic indicators (such as elevated BMI or borderline glucose) indicate potential benefit from lifestyle modifications."
        recommendations = [
            "Consult a qualified healthcare professional or primary care physician for comprehensive clinical evaluation (e.g. fasting glucose and HbA1c testing).",
            "Consider structured dietary adjustments, reducing intake of refined sugars and ultra-processed foods.",
            "Incorporate regular, moderate physical activity to support insulin sensitivity and cardiovascular health.",
            "Monitor blood pressure and fasting blood glucose periodically as advised by your healthcare provider."
        ]
    else:
        category = 'High Risk'
        badge_class = 'bg-danger'
        explanation = f"The model predicts a higher probability ({prob}%) of the positive class. In this project, 'High Risk' is defined as an estimated probability exceeding 65%. Key clinical markers (such as elevated plasma glucose and/or elevated BMI) indicate statistically elevated risk patterns within the training distribution."
        recommendations = [
            "Schedule an appointment with a qualified physician or diabetologist for formal clinical diagnostic assessment.",
            "Undergo certified laboratory testing (including HbA1c, oral glucose tolerance test, and comprehensive metabolic profile).",
            "Discuss personalized medical and dietary interventions with your doctor or a clinical nutritionist.",
            "Important: Do not start, discontinue, or alter any prescribed medications without the explicit direction of your doctor."
        ]

    # Stored inputs summary for record keeping
    stored_inputs = {
        'Glucose': glucose,
        'BloodPressure': bp,
        'Weight_kg': weight_kg,
        'Height_cm': height_cm,
        'BMI': bmi,
        'Age': age,
        'Gender': gender,
        'Pregnancies': pregnancies,
        'Insulin': insulin,
        'SkinThickness': skin_thickness,
        'DiabetesPedigreeFunction': dpf
    }

    return {
        'success': True,
        'is_model_available': True,
        'disease': disease,
        'patient_name': patient_name,
        'city': city,
        'age': age,
        'gender': gender,
        'predicted_category': category,
        'badge_class': badge_class,
        'probability': prob,
        'explanation': explanation,
        'recommendations': recommendations,
        'key_factors': pred_res['key_factors'],
        'inputs': stored_inputs
    }

