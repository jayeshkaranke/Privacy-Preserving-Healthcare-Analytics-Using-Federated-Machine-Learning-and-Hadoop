import subprocess
import json
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
SCRIPT_PATH = BASE_DIR / 'hadoop_mapreduce_stats.py'
HDFS_DATA_PATH = '/user/hadoop/health_data/shared_hospital_records.csv'  # WebHDFS path used by the mock server

def run_hadoop_stats_job():
    """Execute the mrjob MapReduce script against the combined HDFS dataset.
    Returns a list of dicts, one per age bracket, containing the aggregated stats.
    """
    # Build the command – we run the script locally, but the script reads the file via WebHDFS URL internally.
    cmd = [
        'python', str(SCRIPT_PATH),
        '--no-conf',            # avoid picking up any Hadoop conf files
        '-r', 'local',          # run in local mode (works with our mock WebHDFS server)
        '--input', f'http://127.0.0.1:9870/webhdfs/v1{HDFS_DATA_PATH}?op=OPEN'
    ]
    try:
        completed = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=str(BASE_DIR),
            timeout=60
        )
        if completed.returncode != 0:
            raise RuntimeError(f"mrjob failed: {completed.stderr}")
        # Each reducer line is "None\t{json}" – mrjob prints a tab between key and value.
        results = []
        for line in completed.stdout.strip().splitlines():
            # mrjob output is "\t" separated; the JSON is after the first tab.
            parts = line.split('\t', 1)
            if len(parts) == 2:
                try:
                    results.append(json.loads(parts[1]))
                except json.JSONDecodeError:
                    continue
        return results
    except Exception as e:
        # Propagate a clear error for Flask to display.
        raise RuntimeError(f"Error running Hadoop MapReduce stats job: {e}")
