"""
disease_service.py - Multi-Disease Risk Analysis Service.
Coordinates disease-specific machine learning models for Diabetes, Heart Disease,
and Hypertension, while providing clinical explanations and personalized recommendations.
"""

import os
import joblib
import numpy as np
import pandas as pd

from services.federated_service import predict_diabetes_risk

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
MODELS_DIR = os.path.join(BASE_DIR, 'models')

# Model and scaler paths
HEART_MODEL_PATH = os.path.join(MODELS_DIR, 'heart_model.joblib')
HEART_SCALER_PATH = os.path.join(MODELS_DIR, 'heart_scaler.joblib')

HYPERTENSION_MODEL_PATH = os.path.join(MODELS_DIR, 'hypertension_model.joblib')
HYPERTENSION_SCALER_PATH = os.path.join(MODELS_DIR, 'hypertension_scaler.joblib')

ASTHMA_MODEL_PATH = os.path.join(MODELS_DIR, 'asthma_model.joblib')


def calculate_bmi(weight_kg, height_cm):
    """Calculates BMI from weight (kg) and height (cm)."""
    try:
        w = float(weight_kg)
        h = float(height_cm)
        if w <= 0 or h <= 0:
            return 0.0
        h_m = h / 100.0
        return round(w / (h_m * h_m), 2)
    except (ValueError, TypeError, ZeroDivisionError):
        return 0.0


def analyze_disease_risk(disease, personal_info, health_data):
    """
    Main entry point for multi-disease risk analysis.
    Directs the assessment to the appropriate trained model and clinical pipeline.
    """
    disease_clean = disease.strip()

    if disease_clean == 'Diabetes':
        return _analyze_diabetes(personal_info, health_data)
    elif disease_clean == 'Heart Disease':
        return _analyze_heart_disease(personal_info, health_data)
    elif disease_clean == 'Hypertension':
        return _analyze_hypertension(personal_info, health_data)
    elif disease_clean == 'Asthma':
        return _analyze_asthma(personal_info, health_data)
    else:
        return {
            'success': False,
            'is_model_available': False,
            'disease': disease_clean,
            'error': f"Prediction model not available for '{disease_clean}'."
        }


def _analyze_diabetes(personal_info, health_data):
    """Evaluates Diabetes risk using the trained 3-hospital Federated Model."""
    patient_name = str(personal_info.get('patient_name', '')).strip()
    city = str(personal_info.get('city', '')).strip()
    gender = str(personal_info.get('gender', 'Other')).strip()

    if not patient_name:
        raise ValueError("Patient's full name is required.")
    if not city:
        raise ValueError("City name is required.")

    try:
        age = int(personal_info.get('age', 0))
    except (ValueError, TypeError):
        raise ValueError("Age must be a valid whole number.")
    if age < 1 or age > 120:
        raise ValueError("Age must be between 1 and 120 years.")

    weight = float(health_data.get('weight', 0))
    height = float(health_data.get('height', 0))
    bmi = calculate_bmi(weight, height)

    try:
        glucose = float(health_data.get('glucose', 0))
    except (ValueError, TypeError):
        raise ValueError("Glucose level must be a valid numeric measurement.")
    if glucose < 30 or glucose > 400:
        raise ValueError("Glucose level must be between 30 and 400 mg/dL.")

    try:
        bp = float(health_data.get('blood_pressure', 0))
    except (ValueError, TypeError):
        raise ValueError("Blood pressure must be a valid numeric measurement.")

    pregnancies = 0
    if gender.lower() == 'female':
        try:
            pregnancies = int(health_data.get('pregnancies') or 0)
        except (ValueError, TypeError):
            pregnancies = 0

    insulin = float(health_data.get('insulin') or 79.8)
    skin_thickness = float(health_data.get('skin_thickness') or 20.5)
    dpf = float(health_data.get('dpf') or 0.47)

    # Federated model feature dictionary
    features = {
        'Pregnancies': pregnancies,
        'Glucose': glucose,
        'BloodPressure': bp,
        'SkinThickness': skin_thickness,
        'Insulin': insulin,
        'BMI': bmi,
        'DiabetesPedigreeFunction': dpf,
        'Age': age
    }

    pred_res = predict_diabetes_risk(features)
    prob = pred_res['risk_probability']

    # Project-specific probability bands
    if prob < 35.0:
        category = 'Low Risk'
        badge_class = 'bg-success'
        explanation = f"The model predicts a lower probability ({prob}%) of the positive class. In this academic screening system, 'Low Risk' is defined as an estimated probability below 35% (a project-specific screening band, not a universal medical threshold). Most physiological measurements are aligned with normal non-diabetic baselines."
        recommendations = [
            "Maintain a balanced, nutrient-dense diet emphasizing whole grains, leafy vegetables, and lean proteins.",
            "Engage in regular physical activity (such as 150 minutes of moderate aerobic exercise per week).",
            "Continue routine annual preventative health checkups with a certified healthcare professional.",
            "Stay adequately hydrated and ensure consistent, quality sleep hygiene."
        ]
    elif prob <= 65.0:
        category = 'Moderate Risk'
        badge_class = 'bg-warning text-dark'
        explanation = f"The model predicts a moderate / borderline probability ({prob}%) of the positive class. In this project, 'Moderate Risk' corresponds to an estimated probability between 35% and 65%. While not a clinical diagnosis, one or more metabolic indicators (such as elevated BMI or borderline glucose) indicate potential benefit from lifestyle modifications."
        recommendations = [
            "Consult a qualified healthcare professional or primary care physician for comprehensive clinical evaluation (e.g. fasting glucose and HbA1c testing).",
            "Consider structured dietary adjustments, reducing intake of refined sugars and ultra-processed carbohydrates.",
            "Incorporate regular, moderate physical activity to support insulin sensitivity and cardiovascular health.",
            "Monitor blood pressure and fasting blood glucose periodically as advised by your healthcare provider."
        ]
    else:
        category = 'High Risk'
        badge_class = 'bg-danger'
        explanation = f"The model predicts a higher probability ({prob}%) of the positive class. In this project, 'High Risk' is defined as an estimated probability exceeding 65%. Key clinical markers (such as elevated plasma glucose and/or elevated BMI) indicate statistically elevated risk patterns within the training distribution."
        recommendations = [
            "Schedule an appointment with a qualified physician or diabetologist for formal clinical diagnostic assessment.",
            "Undergo certified laboratory testing (including HbA1c, oral glucose tolerance test, and comprehensive metabolic profile).",
            "Discuss personalized medical and dietary interventions with your doctor or a clinical nutritionist.",
            "Important: Do not start, discontinue, or alter any prescribed medications without the explicit direction of your doctor."
        ]

    stored_inputs = {
        'Glucose': glucose,
        'BloodPressure': bp,
        'Weight_kg': weight,
        'Height_cm': height,
        'BMI': bmi,
        'Age': age,
        'Gender': gender,
        'Pregnancies': pregnancies,
        'Insulin': insulin,
        'SkinThickness': skin_thickness,
        'DiabetesPedigreeFunction': dpf
    }

    return {
        'success': True,
        'is_model_available': True,
        'disease': 'Diabetes',
        'patient_name': patient_name,
        'city': city,
        'age': age,
        'gender': gender,
        'predicted_category': category,
        'badge_class': badge_class,
        'probability': prob,
        'explanation': explanation,
        'recommendations': recommendations,
        'inputs': stored_inputs
    }


def _analyze_heart_disease(personal_info, health_data):
    """Evaluates Heart Disease risk using the trained UCI Cleveland model."""
    if not os.path.exists(HEART_MODEL_PATH) or not os.path.exists(HEART_SCALER_PATH):
        raise FileNotFoundError("Heart disease trained model artifact is missing.")

    patient_name = str(personal_info.get('patient_name', '')).strip()
    city = str(personal_info.get('city', '')).strip()
    gender = str(personal_info.get('gender', 'Other')).strip()

    if not patient_name:
        raise ValueError("Patient's full name is required.")
    if not city:
        raise ValueError("City name is required.")

    try:
        age = int(personal_info.get('age', 0))
    except (ValueError, TypeError):
        raise ValueError("Age must be a valid whole number.")

    weight = float(health_data.get('weight', 0))
    height = float(health_data.get('height', 0))
    bmi = calculate_bmi(weight, height)

    sex_val = 1 if gender.lower() == 'male' else 0

    trestbps = float(health_data.get('trestbps', 130))
    chol = float(health_data.get('chol', 220))
    fbs = 1 if str(health_data.get('fbs', '0')).lower() in ['1', 'true', 'yes'] else 0
    cp = int(health_data.get('cp', 0))
    thalach = float(health_data.get('thalach', 150))
    exang = 1 if str(health_data.get('exang', '0')).lower() in ['1', 'true', 'yes'] else 0
    oldpeak = float(health_data.get('oldpeak', 1.0))
    restecg = int(health_data.get('restecg', 0))
    slope = int(health_data.get('slope', 1))
    ca = int(health_data.get('ca', 0))
    thal = int(health_data.get('thal', 2))

    feature_cols = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal']
    input_vals = [age, sex_val, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]

    input_df = pd.DataFrame([input_vals], columns=feature_cols)

    model = joblib.load(HEART_MODEL_PATH)
    scaler = joblib.load(HEART_SCALER_PATH)

    input_scaled = scaler.transform(input_df)
    prob = round(float(model.predict_proba(input_scaled)[0][1]) * 100, 2)

    if prob < 35.0:
        category = 'Low Risk'
        badge_class = 'bg-success'
        explanation = f"The model predicts a lower probability ({prob}%) of the positive class for cardiovascular indicators. Resting blood pressure ({trestbps} mm Hg) and serum cholesterol ({chol} mg/dL) are within manageable statistical ranges."
        recommendations = [
            "Maintain cardiovascular wellness with regular aerobic exercise (walking, swimming, or cycling).",
            "Follow a heart-healthy dietary pattern rich in omega-3 fatty acids, fiber, and low in saturated fats.",
            "Schedule periodic routine cardiovascular checkups and lipid profile screenings.",
            "Avoid tobacco smoke and maintain healthy stress management techniques."
        ]
    elif prob <= 65.0:
        category = 'Moderate Risk'
        badge_class = 'bg-warning text-dark'
        explanation = f"The model predicts a moderate / borderline probability ({prob}%) of the positive class. One or more cardiovascular factors (such as elevated cholesterol or chest discomfort) suggest proactive evaluation."
        recommendations = [
            "Schedule an evaluation with a physician or cardiologist for resting ECG and advanced lipid testing.",
            "Adopt structured dietary modifications to lower LDL cholesterol and manage vascular health.",
            "Engage in physician-approved physical activity to support arterial compliance.",
            "Monitor blood pressure and resting pulse rate regularly."
        ]
    else:
        category = 'High Risk'
        badge_class = 'bg-danger'
        explanation = f"The model predicts a higher probability ({prob}%) of the positive class. Key markers (such as elevated blood pressure, cholesterol, and/or exercise-induced symptoms) indicate statistically elevated cardiovascular risk patterns."
        recommendations = [
            "Promptly consult a certified cardiologist for a comprehensive cardiac diagnostic evaluation.",
            "Undergo specialized testing such as an Exercise Stress Test, Echocardiogram, and comprehensive lipid panel.",
            "Follow strict medical advice regarding lifestyle, dietary sodium reduction, and medication management.",
            "Do not stop or adjust any prescribed cardiovascular medications without direct physician supervision."
        ]

    stored_inputs = {
        'Age': age,
        'Gender': gender,
        'Weight_kg': weight,
        'Height_cm': height,
        'BMI': bmi,
        'RestingBloodPressure': trestbps,
        'Cholesterol': chol,
        'FastingBloodSugar': 'Yes (>120 mg/dL)' if fbs == 1 else 'No',
        'ChestPainType': f"Type {cp}",
        'MaxHeartRate': thalach,
        'ExerciseAngina': 'Yes' if exang == 1 else 'No',
        'STDepression': oldpeak
    }

    return {
        'success': True,
        'is_model_available': True,
        'disease': 'Heart Disease',
        'patient_name': patient_name,
        'city': city,
        'age': age,
        'gender': gender,
        'predicted_category': category,
        'badge_class': badge_class,
        'probability': prob,
        'explanation': explanation,
        'recommendations': recommendations,
        'inputs': stored_inputs
    }


def _analyze_hypertension(personal_info, health_data):
    """Evaluates Hypertension risk using the trained blood pressure risk model."""
    if not os.path.exists(HYPERTENSION_MODEL_PATH) or not os.path.exists(HYPERTENSION_SCALER_PATH):
        raise FileNotFoundError("Hypertension trained model artifact is missing.")

    patient_name = str(personal_info.get('patient_name', '')).strip()
    city = str(personal_info.get('city', '')).strip()
    gender = str(personal_info.get('gender', 'Other')).strip()

    if not patient_name:
        raise ValueError("Patient's full name is required.")
    if not city:
        raise ValueError("City name is required.")

    try:
        age = int(personal_info.get('age', 0))
    except (ValueError, TypeError):
        raise ValueError("Age must be a valid whole number.")

    weight = float(health_data.get('weight', 0))
    height = float(health_data.get('height', 0))
    bmi = calculate_bmi(weight, height)

    sex_val = 1 if gender.lower() == 'male' else 0
    chol = float(health_data.get('chol', 210))
    fbs = 1 if str(health_data.get('fbs', '0')).lower() in ['1', 'true', 'yes'] else 0
    thalach = float(health_data.get('thalach', 145))

    try:
        systolic_bp = float(health_data.get('systolic_bp', 125))
    except (ValueError, TypeError):
        systolic_bp = 125.0

    try:
        diastolic_bp = float(health_data.get('diastolic_bp', 80))
    except (ValueError, TypeError):
        diastolic_bp = 80.0

    feature_cols = ['age', 'sex', 'systolic_bp', 'diastolic_bp', 'chol', 'bmi', 'fbs', 'thalach']
    input_vals = [age, sex_val, systolic_bp, diastolic_bp, chol, bmi, fbs, thalach]

    input_df = pd.DataFrame([input_vals], columns=feature_cols)

    model = joblib.load(HYPERTENSION_MODEL_PATH)
    scaler = joblib.load(HYPERTENSION_SCALER_PATH)

    input_scaled = scaler.transform(input_df)
    prob = round(float(model.predict_proba(input_scaled)[0][1]) * 100, 2)

    # In clinical guidelines, if measured systolic >= 140 or diastolic >= 90, probability reflects confirmed elevation
    if systolic_bp >= 140 or diastolic_bp >= 90:
        prob = max(prob, 72.5)
    elif systolic_bp >= 130 or diastolic_bp >= 85:
        prob = max(prob, 52.0)

    if prob < 35.0:
        category = 'Low Risk'
        badge_class = 'bg-success'
        explanation = f"The model predicts a lower probability ({prob}%) of the positive class for hypertensive risk. Blood pressure readings ({int(systolic_bp)}/{int(diastolic_bp)} mm Hg) fall within normal or pre-hypertensive baseline ranges."
        recommendations = [
            "Maintain a low-sodium, mineral-rich diet (such as the DASH eating plan).",
            "Engage in consistent daily physical movement and aerobic fitness.",
            "Check resting blood pressure at least once every 6 months.",
            "Maintain balanced hydration and stress management."
        ]
    elif prob <= 65.0:
        category = 'Moderate Risk'
        badge_class = 'bg-warning text-dark'
        explanation = f"The model predicts a moderate / borderline probability ({prob}%) of the positive class. Current arterial readings ({int(systolic_bp)}/{int(diastolic_bp)} mm Hg) indicate Stage 1 elevated vascular pressure."
        recommendations = [
            "Consult a physician or primary healthcare clinic for repeated seated blood pressure measurements.",
            "Reduce dietary sodium intake to less than 2,000 mg per day.",
            "Incorporate 30 minutes of daily moderate cardiovascular exercise.",
            "Limit caffeine and alcohol consumption and monitor blood pressure weekly."
        ]
    else:
        category = 'High Risk'
        badge_class = 'bg-danger'
        explanation = f"The model predicts a higher probability ({prob}%) of the positive class. Blood pressure readings ({int(systolic_bp)}/{int(diastolic_bp)} mm Hg) indicate Stage 2 hypertensive patterns requiring formal clinical management."
        recommendations = [
            "Schedule an immediate consultation with a qualified medical doctor or hypertension specialist.",
            "Undergo comprehensive renal, cardiovascular, and electrolyte laboratory testing.",
            "Adhere strictly to medical advice regarding antihypertensive therapy and dietary sodium reduction.",
            "Do not alter or discontinue any prescribed blood pressure medications without physician consent."
        ]

    stored_inputs = {
        'Age': age,
        'Gender': gender,
        'Weight_kg': weight,
        'Height_cm': height,
        'BMI': bmi,
        'SystolicBP': systolic_bp,
        'DiastolicBP': diastolic_bp,
        'Cholesterol': chol,
        'FastingBloodSugar': 'Yes' if fbs == 1 else 'No',
        'RestingHeartRate': thalach
    }

    return {
        'success': True,
        'is_model_available': True,
        'disease': 'Hypertension',
        'patient_name': patient_name,
        'city': city,
        'age': age,
        'gender': gender,
        'predicted_category': category,
        'badge_class': badge_class,
        'probability': prob,
        'explanation': explanation,
        'recommendations': recommendations,
        'inputs': stored_inputs
    }


def _analyze_asthma(personal_info, health_data):
    """Evaluates Asthma risk using the trained Random Forest symptom classification model."""
    if not os.path.exists(ASTHMA_MODEL_PATH):
        raise FileNotFoundError("Asthma trained model artifact is missing. Please ensure models/asthma_model.joblib exists.")

    patient_name = str(personal_info.get('patient_name', '')).strip()
    city = str(personal_info.get('city', '')).strip()
    gender = str(personal_info.get('gender', 'Other')).strip()

    if not patient_name:
        raise ValueError("Patient's full name is required.")
    if not city:
        raise ValueError("City name is required.")

    try:
        age = int(personal_info.get('age', 0))
    except (ValueError, TypeError):
        raise ValueError("Age must be a valid whole number.")
    if age < 1 or age > 120:
        raise ValueError("Age must be between 1 and 120 years.")

    weight = float(health_data.get('weight', 0))
    height = float(health_data.get('height', 0))
    bmi = calculate_bmi(weight, height)

    # Helper for boolean flags / checkboxes
    def parse_flag(val):
        return 1 if str(val).lower() in ['1', 'true', 'yes', 'on'] else 0

    diff_breathing = parse_flag(health_data.get('difficulty_breathing', 0))
    dry_cough = parse_flag(health_data.get('dry_cough', 0))
    nasal_congestion = parse_flag(health_data.get('nasal_congestion', 0))
    sore_throat = parse_flag(health_data.get('sore_throat', 0))
    tiredness = parse_flag(health_data.get('tiredness', 0))
    runny_nose = parse_flag(health_data.get('runny_nose', 0))
    pains = parse_flag(health_data.get('pains', 0))

    symptom_count = diff_breathing + dry_cough + nasal_congestion + sore_throat + tiredness + runny_nose + pains
    none_symptom = 1 if symptom_count == 0 else 0

    # Age one-hot encoding
    age_0_9 = 1 if age <= 9 else 0
    age_10_19 = 1 if 10 <= age <= 19 else 0
    age_20_24 = 1 if 20 <= age <= 24 else 0
    age_25_59 = 1 if 25 <= age <= 59 else 0
    age_60_plus = 1 if age >= 60 else 0

    # Gender one-hot encoding
    gender_female = 1 if gender.lower() == 'female' else 0
    gender_male = 1 if gender.lower() == 'male' else 0

    feature_cols = [
        'Difficulty-in-Breathing', 'Dry-Cough', 'Nasal-Congestion', 'Sore-Throat', 
        'Tiredness', 'Runny-Nose', 'Pains', 'None_Sympton', 
        'Age_0-9', 'Age_10-19', 'Age_20-24', 'Age_25-59', 'Age_60+', 
        'Gender_Female', 'Gender_Male'
    ]
    input_vals = [
        diff_breathing, dry_cough, nasal_congestion, sore_throat,
        tiredness, runny_nose, pains, none_symptom,
        age_0_9, age_10_19, age_20_24, age_25_59, age_60_plus,
        gender_female, gender_male
    ]

    input_df = pd.DataFrame([input_vals], columns=feature_cols)

    model = joblib.load(ASTHMA_MODEL_PATH)
    prob = round(float(model.predict_proba(input_df)[0][1]) * 100, 2)

    if prob < 35.0:
        category = 'Low Risk'
        badge_class = 'bg-success'
        explanation = f"The model predicts a low probability ({prob}%) of asthmatic airway hypersensitivity. Key respiratory symptoms like dyspnea and persistent cough are absent or minimal."
        recommendations = [
            "Maintain respiratory health with routine physical conditioning and clean indoor ventilation.",
            "Avoid exposure to secondhand smoke, chemical fumes, and heavy industrial pollutants.",
            "Stay up to date on seasonal influenza vaccinations and practice good respiratory hygiene.",
            "If respiratory discomfort or nocturnal coughing emerges, arrange an in-person clinical checkup."
        ]
    elif prob <= 65.0:
        category = 'Moderate Risk'
        badge_class = 'bg-warning text-dark'
        explanation = f"The model predicts a moderate / borderline probability ({prob}%) of asthmatic respiratory involvement. Presence of upper airway irritation or mild cough warrants pulmonary screening."
        recommendations = [
            "Consult a pulmonologist or general physician for formal pulmonary evaluation, including Spirometry (FEV1/FVC).",
            "Identify and minimize exposure to potential allergic triggers such as pollen, pet dander, and dust mites.",
            "Keep a symptom diary tracking when cough, nasal congestion, or shortness of breath occur.",
            "Consider using a HEPA air filtration purifier in sleeping and living quarters."
        ]
    else:
        category = 'High Risk'
        badge_class = 'bg-danger'
        explanation = f"The model predicts a higher probability ({prob}%) of active asthmatic or bronchial hyperresponsiveness. Cardinal symptoms including breathing difficulty, persistent dry cough, and nasal congestion indicate statistically elevated respiratory risk."
        recommendations = [
            "Schedule an urgent clinical evaluation with a certified pulmonologist or respiratory specialist.",
            "Undergo formal pulmonary function testing (PFT) and bronchial reversibility evaluation.",
            "Discuss an Asthma Action Plan and inhaler/bronchodilator suitability with your physician.",
            "Seek immediate emergency medical care if experiencing severe breathlessness, speaking difficulty, or bluish lips/fingertips."
        ]

    stored_inputs = {
        'Age': age,
        'Gender': gender,
        'Weight_kg': weight,
        'Height_cm': height,
        'BMI': bmi,
        'BreathingDifficulty': 'Present' if diff_breathing == 1 else 'Absent',
        'DryCough': 'Present' if dry_cough == 1 else 'Absent',
        'NasalCongestion': 'Present' if nasal_congestion == 1 else 'Absent',
        'SoreThroat': 'Present' if sore_throat == 1 else 'Absent',
        'Fatigue': 'Present' if tiredness == 1 else 'Absent',
        'RunnyNose': 'Present' if runny_nose == 1 else 'Absent',
        'BodyPains': 'Present' if pains == 1 else 'Absent'
    }

    return {
        'success': True,
        'is_model_available': True,
        'disease': 'Asthma',
        'patient_name': patient_name,
        'city': city,
        'age': age,
        'gender': gender,
        'predicted_category': category,
        'badge_class': badge_class,
        'probability': prob,
        'explanation': explanation,
        'recommendations': recommendations,
        'inputs': stored_inputs
    }

