"""
data_service.py - Data management and preprocessing service.
Handles dataset loading, missing-value imputation, and partitioning into 3 hospital datasets
plus a holdout evaluation test set.
"""

import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DATA_DIR = os.path.join(BASE_DIR, 'data')

RAW_DATA_PATH = os.path.join(DATA_DIR, 'diabetes.csv')
HOSPITAL_A_PATH = os.path.join(DATA_DIR, 'hospital_A.csv')
HOSPITAL_B_PATH = os.path.join(DATA_DIR, 'hospital_B.csv')
HOSPITAL_C_PATH = os.path.join(DATA_DIR, 'hospital_C.csv')
TEST_DATA_PATH = os.path.join(DATA_DIR, 'test_data.csv')

FEATURE_COLUMNS = [
    'Pregnancies',
    'Glucose',
    'BloodPressure',
    'SkinThickness',
    'Insulin',
    'BMI',
    'DiabetesPedigreeFunction',
    'Age'
]
TARGET_COLUMN = 'Outcome'

# Columns where 0 indicates biologically impossible missing value
ZERO_AS_MISSING_COLS = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']

HOSPITAL_METADATA = {
    'Hospital_A': {
        'id': 'Hospital_A',
        'name': 'Sunrise Multispeciality Hospital',
        'location': 'Central Healthcare District',
        'file': HOSPITAL_A_PATH,
        'badge': 'bg-primary'
    },
    'Hospital_B': {
        'id': 'Hospital_B',
        'name': 'CityCare Medical Centre',
        'location': 'Metro North Wing',
        'file': HOSPITAL_B_PATH,
        'badge': 'bg-info'
    },
    'Hospital_C': {
        'id': 'Hospital_C',
        'name': 'GreenLife Hospital',
        'location': 'Suburban Care Campus',
        'file': HOSPITAL_C_PATH,
        'badge': 'bg-success'
    }
}


def prepare_and_partition_data(force=False):
    """
    Loads raw diabetes.csv, handles missing values (0s in physiological readings),
    splits 20% into test_data.csv, and partitions the remaining 80% equally among
    Hospital A, Hospital B, and Hospital C.
    """
    os.makedirs(DATA_DIR, exist_ok=True)

    # Check if partitioned files already exist
    all_exist = all(os.path.exists(p) for p in [HOSPITAL_A_PATH, HOSPITAL_B_PATH, HOSPITAL_C_PATH, TEST_DATA_PATH])
    if all_exist and not force:
        return

    if not os.path.exists(RAW_DATA_PATH):
        raise FileNotFoundError(f"Raw dataset not found at {RAW_DATA_PATH}. Please provide diabetes.csv.")

    df = pd.read_csv(RAW_DATA_PATH)

    # Clean missing values: replace 0 with NaN then impute with median
    df_clean = df.copy()
    for col in ZERO_AS_MISSING_COLS:
        if col in df_clean.columns:
            median_val = df_clean[df_clean[col] > 0][col].median()
            df_clean[col] = df_clean[col].replace(0, median_val)

    # Holdout 20% for central evaluation
    train_df, test_df = train_test_split(df_clean, test_size=0.20, random_state=42, stratify=df_clean[TARGET_COLUMN])
    test_df.to_csv(TEST_DATA_PATH, index=False)

    # Partition training set into 3 simulated hospitals
    # Shuffle first with fixed seed for reproducibility
    train_df = train_df.sample(frac=1.0, random_state=42).reset_index(drop=True)
    n = len(train_df)
    n_third = n // 3

    df_a = train_df.iloc[:n_third].copy()
    df_b = train_df.iloc[n_third:2 * n_third].copy()
    df_c = train_df.iloc[2 * n_third:].copy()

    df_a.to_csv(HOSPITAL_A_PATH, index=False)
    df_b.to_csv(HOSPITAL_B_PATH, index=False)
    df_c.to_csv(HOSPITAL_C_PATH, index=False)


def load_hospital_data(hospital_key):
    """Returns X, y for a specific hospital."""
    prepare_and_partition_data()
    meta = HOSPITAL_METADATA.get(hospital_key)
    if not meta or not os.path.exists(meta['file']):
        raise ValueError(f"Hospital file not found for {hospital_key}")
    df = pd.read_csv(meta['file'])
    X = df[FEATURE_COLUMNS]
    y = df[TARGET_COLUMN]
    return X, y


def load_test_data():
    """Returns X_test, y_test for holdout evaluation."""
    prepare_and_partition_data()
    if not os.path.exists(TEST_DATA_PATH):
        raise ValueError(f"Test dataset not found at {TEST_DATA_PATH}")
    df = pd.read_csv(TEST_DATA_PATH)
    X = df[FEATURE_COLUMNS]
    y = df[TARGET_COLUMN]
    return X, y


def get_dataset_summary():
    """Returns overview statistics of raw and partitioned data."""
    prepare_and_partition_data()
    df_raw = pd.read_csv(RAW_DATA_PATH)
    total_records = len(df_raw)
    positive_count = int((df_raw[TARGET_COLUMN] == 1).sum())
    negative_count = int((df_raw[TARGET_COLUMN] == 0).sum())

    hospitals_info = get_hospitals_overview()

    # Previews
    preview_rows = df_raw.head(8).to_dict(orient='records')
    feature_stats = []
    for col in FEATURE_COLUMNS:
        feature_stats.append({
            'name': col,
            'mean': round(float(df_raw[col].mean()), 2),
            'median': round(float(df_raw[col].median()), 2),
            'min': round(float(df_raw[col].min()), 2),
            'max': round(float(df_raw[col].max()), 2),
            'zeros': int((df_raw[col] == 0).sum())
        })

    return {
        'total_records': total_records,
        'positive_count': positive_count,
        'negative_count': negative_count,
        'positive_pct': round((positive_count / total_records) * 100, 1),
        'negative_pct': round((negative_count / total_records) * 100, 1),
        'features': FEATURE_COLUMNS,
        'feature_stats': feature_stats,
        'preview_rows': preview_rows,
        'hospitals': hospitals_info
    }


def get_hospitals_overview():
    """Returns summary for each hospital."""
    prepare_and_partition_data()
    summary = []
    for key, meta in HOSPITAL_METADATA.items():
        if os.path.exists(meta['file']):
            df = pd.read_csv(meta['file'])
            pos = int((df[TARGET_COLUMN] == 1).sum())
            neg = int((df[TARGET_COLUMN] == 0).sum())
            summary.append({
                'id': key,
                'name': meta['name'],
                'location': meta['location'],
                'badge': meta['badge'],
                'total_records': len(df),
                'positive': pos,
                'negative': neg,
                'mean_age': round(float(df['Age'].mean()), 1),
                'mean_glucose': round(float(df['Glucose'].mean()), 1),
                'mean_bmi': round(float(df['BMI'].mean()), 1),
                'file_name': os.path.basename(meta['file'])
            })
    return summary


def get_feature_medians():
    """Computes medians across cleaned data to supply realistic default values in form."""
    prepare_and_partition_data()
    df = pd.read_csv(RAW_DATA_PATH)
    medians = {}
    for col in FEATURE_COLUMNS:
        if col in ZERO_AS_MISSING_COLS:
            val = df[df[col] > 0][col].median()
        else:
            val = df[col].median()
        medians[col] = round(float(val), 2)
    return medians
