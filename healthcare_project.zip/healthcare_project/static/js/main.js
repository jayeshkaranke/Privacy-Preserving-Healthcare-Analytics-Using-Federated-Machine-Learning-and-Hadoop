/**
 * main.js - Healthcare Analytics Frontend Interaction Script
 * Manages Light/Dark theme switching, real-time BMI calculation, and preset loaders.
 */

// Theme Management
function initTheme() {
    const savedTheme = localStorage.getItem('health_analytics_theme') || 'light';
    setTheme(savedTheme);
}

function setTheme(theme) {
    document.documentElement.setAttribute('data-bs-theme', theme);
    if (document.body) {
        document.body.setAttribute('data-bs-theme', theme);
    }
    localStorage.setItem('health_analytics_theme', theme);
    
    const themeBtn = document.getElementById('themeToggleBtn');
    if (themeBtn) {
        if (theme === 'dark') {
            themeBtn.innerHTML = '<i class="bi bi-moon-stars-fill text-warning"></i> <span>Dark</span>';
            themeBtn.title = 'Switch to Light Mode';
        } else {
            themeBtn.innerHTML = '<i class="bi bi-sun-fill text-warning"></i> <span>Light</span>';
            themeBtn.title = 'Switch to Dark Mode';
        }
    }
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-bs-theme') || 'light';
    const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
}

// Automatic BMI Calculation
function updateBmiCalculation() {
    const weightInput = document.getElementById('inpWeight');
    const heightInput = document.getElementById('inpHeight');
    const bmiDisplay = document.getElementById('calculatedBmi');
    const bmiBadge = document.getElementById('bmiBadge');

    if (!weightInput || !heightInput || !bmiDisplay) return;

    const weight = parseFloat(weightInput.value);
    const height = parseFloat(heightInput.value);

    if (weight > 0 && height > 0) {
        const heightM = height / 100.0;
        const bmi = (weight / (heightM * heightM)).toFixed(2);
        bmiDisplay.innerText = bmi;

        if (bmiBadge) {
            bmiBadge.classList.remove('d-none', 'bg-success', 'bg-info', 'bg-warning', 'bg-danger', 'text-dark');
            if (bmi < 18.5) {
                bmiBadge.classList.add('bg-info', 'text-dark');
                bmiBadge.innerText = 'Underweight (<18.5)';
            } else if (bmi < 25.0) {
                bmiBadge.classList.add('bg-success');
                bmiBadge.innerText = 'Normal (18.5–24.9)';
            } else if (bmi < 30.0) {
                bmiBadge.classList.add('bg-warning', 'text-dark');
                bmiBadge.innerText = 'Overweight (25–29.9)';
            } else {
                bmiBadge.classList.add('bg-danger');
                bmiBadge.innerText = 'Obese (≥30)';
            }
        }
    } else {
        bmiDisplay.innerText = '--';
        if (bmiBadge) bmiBadge.classList.add('d-none');
    }
}

// Gender change handler for pregnancies visibility
function handleGenderChange() {
    const genderSelect = document.getElementById('inpGender');
    const pregWrapper = document.getElementById('pregnanciesWrapper');
    const pregInput = document.getElementById('inpPregnancies');

    if (!genderSelect || !pregWrapper) return;

    if (genderSelect.value === 'Female') {
        pregWrapper.style.opacity = '1';
        if (pregInput) pregInput.disabled = false;
    } else {
        pregWrapper.style.opacity = '0.5';
        if (pregInput) {
            pregInput.value = 0;
            pregInput.disabled = true;
        }
    }
}

// Initialize on DOM load
document.addEventListener("DOMContentLoaded", function () {
    initTheme();

    const themeBtn = document.getElementById('themeToggleBtn');
    if (themeBtn) {
        themeBtn.addEventListener('click', toggleTheme);
    }

    const weightInput = document.getElementById('inpWeight');
    const heightInput = document.getElementById('inpHeight');
    if (weightInput && heightInput) {
        weightInput.addEventListener('input', updateBmiCalculation);
        heightInput.addEventListener('input', updateBmiCalculation);
        updateBmiCalculation();
    }

    const genderSelect = document.getElementById('inpGender');
    if (genderSelect) {
        genderSelect.addEventListener('change', handleGenderChange);
        handleGenderChange();
    }

    // Bootstrap Tooltips initialization
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
