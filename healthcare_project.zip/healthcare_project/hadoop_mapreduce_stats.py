from mrjob.job import MRJob
import json

class HealthStatsJob(MRJob):
    """MapReduce job that computes:
    1) High‑risk vs low‑risk patient counts per age bracket.
    2) Average BMI, BloodPressure, and Glucose for high‑risk patients.

    Expected CSV columns (header row):
        Pregnancies,Glucose,BloodPressure,SkinThickness,Insulin,BMI,DiabetesPedigreeFunction,Age,Outcome
    """

    # ---------------------------------------------------------------------
    # Helper to map a numeric age to a bracket string
    # ---------------------------------------------------------------------
    def age_bracket(self, age):
        if age < 30:
            return "Under 30"
        elif age <= 50:
            return "30-50"
        else:
            return "Over 50"

    # ---------------------------------------------------------------------
    # Mapper: emit one line per patient
    # Key   -> age bracket
    # Value -> JSON string with fields we need to aggregate
    # ---------------------------------------------------------------------
    def mapper(self, _, line):
        # Skip header line if it contains the word "Outcome"
        if "Outcome" in line:
            return
        parts = line.strip().split(',')
        if len(parts) < 9:
            return  # malformed line
        try:
            age = int(parts[7])
            outcome = int(parts[8])  # 1 = high risk, 0 = low risk
            bmi = float(parts[5])
            bp = float(parts[2])
            glucose = float(parts[1])
        except ValueError:
            return
        bracket = self.age_bracket(age)
        # For low‑risk patients we still need the count, but vitals are ignored in the average.
        record = {
            "high_risk": outcome,
            "bmi": bmi if outcome == 1 else 0.0,
            "bp": bp if outcome == 1 else 0.0,
            "glucose": glucose if outcome == 1 else 0.0,
            "count": 1
        }
        yield bracket, json.dumps(record)

    # ---------------------------------------------------------------------
    # Combiner: local aggregation to reduce data shuffling
    # ---------------------------------------------------------------------
    def combiner(self, bracket, records):
        high_risk = low_risk = 0
        bmi_sum = bp_sum = glucose_sum = 0.0
        high_risk_cnt = 0
        total_cnt = 0
        for rec_json in records:
            rec = json.loads(rec_json)
            total_cnt += rec["count"]
            if rec["high_risk"] == 1:
                high_risk += 1
                high_risk_cnt += 1
                bmi_sum += rec["bmi"]
                bp_sum += rec["bp"]
                glucose_sum += rec["glucose"]
            else:
                low_risk += 1
        agg = {
            "high_risk": high_risk,
            "low_risk": low_risk,
            "bmi_sum": bmi_sum,
            "bp_sum": bp_sum,
            "glucose_sum": glucose_sum,
            "high_risk_cnt": high_risk_cnt,
            "total_cnt": total_cnt
        }
        yield bracket, json.dumps(agg)

    # ---------------------------------------------------------------------
    # Reducer: final aggregation and calculation of averages
    # ---------------------------------------------------------------------
    def reducer(self, bracket, records):
        high_risk = low_risk = 0
        bmi_sum = bp_sum = glucose_sum = 0.0
        high_risk_cnt = 0
        total_cnt = 0
        for rec_json in records:
            rec = json.loads(rec_json)
            high_risk += rec.get("high_risk", 0)
            low_risk += rec.get("low_risk", 0)
            bmi_sum += rec.get("bmi_sum", 0.0)
            bp_sum += rec.get("bp_sum", 0.0)
            glucose_sum += rec.get("glucose_sum", 0.0)
            high_risk_cnt += rec.get("high_risk_cnt", 0)
            total_cnt += rec.get("total_cnt", 0)
        # Compute averages for high‑risk patients only (avoid division by zero)
        if high_risk_cnt > 0:
            avg_bmi = bmi_sum / high_risk_cnt
            avg_bp = bp_sum / high_risk_cnt
            avg_glucose = glucose_sum / high_risk_cnt
        else:
            avg_bmi = avg_bp = avg_glucose = 0.0
        result = {
            "age_bracket": bracket,
            "high_risk_count": high_risk,
            "low_risk_count": low_risk,
            "total_patients": total_cnt,
            "avg_bmi_high_risk": round(avg_bmi, 2),
            "avg_bp_high_risk": round(avg_bp, 2),
            "avg_glucose_high_risk": round(avg_glucose, 2)
        }
        # Emit a single line of JSON per bucket – Flask can read this easily.
        yield None, json.dumps(result)

if __name__ == '__main__':
    HealthStatsJob.run()
