"""
Persistent Mobile Link Daemon for Healthcare Analytics Project.
Keeps an active public HTTPS tunnel connected to Flask on port 5000.
Automatically reconnects if the remote server disconnects.
"""
import subprocess
import time
import re
import sys

def start_persistent_tunnel():
    print("=" * 65)
    print("Starting Persistent Mobile Tunnel for Healthcare Project...")
    print("=" * 65)

    cmd = [
        "ssh",
        "-R", "80:127.0.0.1:5000",
        "-o", "StrictHostKeyChecking=no",
        "-o", "ServerAliveInterval=20",
        "-o", "ServerAliveCountMax=5",
        "nokey@localhost.run"
    ]

    while True:
        try:
            print("[Tunnel] Connecting to secure tunnel gateway...", flush=True)
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                encoding='utf-8',
                errors='replace'
            )

            current_url = None
            for line in proc.stdout:
                line_str = line.strip()
                match = re.search(r'https://[a-zA-Z0-9\.\-]+\.lhr\.life', line_str)
                if match:
                    current_url = match.group(0)
                    print("\n" + "=" * 65, flush=True)
                    print(f"MOBILE LINK IS READY:", flush=True)
                    print(f"   {current_url}", flush=True)
                    print("=" * 65 + "\n", flush=True)

            proc.wait()
            print("[Tunnel] Connection dropped. Reconnecting in 3 seconds...", flush=True)
            time.sleep(3)

        except KeyboardInterrupt:
            print("[Tunnel] Stopped by user.", flush=True)
            break
        except Exception as e:
            print(f"[Tunnel] Error: {e}. Reconnecting in 5 seconds...", flush=True)
            time.sleep(5)

if __name__ == "__main__":
    start_persistent_tunnel()
