import os
import sys

base_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, base_dir)

from services.disease_service import analyze_disease_risk

p_info = {'patient_name': 'Aarav Patel', 'city': 'Mumbai', 'age': '45', 'gender': 'Male'}

# 1. Diabetes
d_res = analyze_disease_risk('Diabetes', p_info, {'weight': '82', 'height': '175', 'glucose': '145', 'blood_pressure': '82', 'insulin': '160', 'skin_thickness': '28', 'dpf': '0.62'})
print('Diabetes Prediction:', d_res['predicted_category'], f"{d_res['probability']}%")

# 2. Heart Disease
h_res = analyze_disease_risk('Heart Disease', p_info, {'weight': '80', 'height': '172', 'trestbps': '135', 'chol': '240', 'thalach': '140', 'cp': '2', 'fbs': '0', 'exang': '0', 'oldpeak': '1.2', 'restecg': '0', 'slope': '1', 'ca': '0', 'thal': '2'})
print('Heart Disease Prediction:', h_res['predicted_category'], f"{h_res['probability']}%")

# 3. Hypertension
ht_res = analyze_disease_risk('Hypertension', p_info, {'weight': '78', 'height': '170', 'systolic_bp': '142', 'diastolic_bp': '92', 'chol': '210', 'fbs': '0', 'restecg': '0', 'thalach': '145'})
print('Hypertension Prediction:', ht_res['predicted_category'], f"{ht_res['probability']}%")

# 4. Asthma
a_res = analyze_disease_risk('Asthma', p_info, {'weight': '75', 'height': '170', 'difficulty_breathing': '1', 'dry_cough': '1', 'nasal_congestion': '1', 'sore_throat': '0', 'tiredness': '1', 'runny_nose': '1', 'pains': '0'})
print('Asthma Prediction:', a_res['predicted_category'], f"{a_res['probability']}%")

print("\nAll 4 disease risk evaluations executed successfully!")
