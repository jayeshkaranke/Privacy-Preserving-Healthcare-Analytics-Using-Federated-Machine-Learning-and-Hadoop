"""
app.py - Main Flask Web Application
Privacy-Preserving Healthcare Analytics Using Federated Machine Learning and Hadoop
"""

import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_from_directory

from services.data_service import (
    get_dataset_summary,
    prepare_and_partition_data
)
from services.federated_service import (
    run_federated_pipeline,
    get_federated_status,
    predict_diabetes_risk
)
from services.disease_service import (
    analyze_disease_risk,
    calculate_bmi
)
# New HDFS and MapReduce services
from services.hdfs_data_service import upload_to_hdfs, deidentify_dataframe, load_training_data_from_hdfs
from services.hdfs_model_service import retrain_global_model_from_hdfs
from services.hadoop_stats_service import run_hadoop_stats_job

from services.hadoop_service import (
    get_hadoop_config,
    save_hadoop_config,
    check_hadoop_connection,
    get_hdfs_storage_status,
    upload_datasets_to_hdfs
)
from services.db_service import (
    init_db,
    save_assessment,
    get_all_assessments,
    get_assessment_by_id,
    get_recent_assessments,
    get_total_assessments_count
)

app = Flask(__name__)
app.secret_key = 'healthcare-federated-analytics-secret-key-2026'

# Initialize database, partitioned datasets, and federated model on application startup
prepare_and_partition_data()
get_federated_status()
init_db()


# ---------------- 1. Dashboard ----------------

@app.route('/')
def dashboard():
    """
    Main Healthcare Dashboard:
    Displays welcome message, actual total patient dataset records,
    total saved patient records, and recent patient analyses history.
    """
    dataset_summary = get_dataset_summary()
    total_dataset_records = dataset_summary.get('total_records', 768)
    total_assessments_count = get_total_assessments_count()
    recent_assessments = get_recent_assessments(limit=5)

    return render_template(
        'index.html',
        total_dataset_records=total_dataset_records,
        total_assessments_count=total_assessments_count,
        recent_assessments=recent_assessments,
        dataset_summary=dataset_summary
    )


# ---------------- 2. Risk Analysis ----------------

@app.route('/risk-analysis', methods=['GET', 'POST'])
def risk_analysis_view():
    """
    Risk Analysis Workflow:
    Screen 1: Disease Selection (4 clickable condition cards).
    Screen 2: Patient Assessment Form (demographics + condition-specific fields).
    Screen 3: Display Risk Analysis Results (with auto-saving to SQLite).
    """
    assessment_result = None
    error_message = None
    form_data = {}

    selected_disease = request.args.get('disease')
    record_id_query = request.args.get('record_id')

    # If displaying result from a completed analysis (PRG pattern)
    if record_id_query:
        saved_record = get_assessment_by_id(record_id_query)
        if saved_record:
            badge_class = 'bg-success'
            if saved_record['predicted_category'] == 'High Risk':
                badge_class = 'bg-danger'
            elif saved_record['predicted_category'] == 'Moderate Risk':
                badge_class = 'bg-warning text-dark'

            assessment_result = {
                'success': True,
                'record_id': saved_record['record_id'],
                'patient_name': saved_record['patient_name'],
                'city': saved_record['city'],
                'age': saved_record['age'],
                'gender': saved_record['gender'],
                'disease': saved_record['disease'],
                'predicted_category': saved_record['predicted_category'],
                'badge_class': badge_class,
                'probability': saved_record['probability'],
                'explanation': saved_record['explanation'],
                'recommendations': saved_record['recommendations'],
                'inputs': saved_record['inputs']
            }

    if request.method == 'POST':
        disease = request.form.get('disease', 'Diabetes').strip()
        selected_disease = disease

        personal_info = {
            'patient_name': request.form.get('patient_name', '').strip(),
            'city': request.form.get('city', '').strip(),
            'age': request.form.get('age', '').strip(),
            'gender': request.form.get('gender', 'Other').strip()
        }

        # Collect all possible clinical inputs
        health_data = {
            'weight': request.form.get('weight', '').strip(),
            'height': request.form.get('height', '').strip(),
            # Diabetes specific
            'glucose': request.form.get('glucose', '').strip(),
            'blood_pressure': request.form.get('blood_pressure', '').strip(),
            'pregnancies': request.form.get('pregnancies', '0').strip(),
            'insulin': request.form.get('insulin', '').strip(),
            'skin_thickness': request.form.get('skin_thickness', '').strip(),
            'dpf': request.form.get('dpf', '').strip(),
            # Heart disease specific
            'trestbps': request.form.get('trestbps', '').strip(),
            'chol': request.form.get('chol', '').strip(),
            'cp': request.form.get('cp', '0').strip(),
            'thalach': request.form.get('thalach', '').strip(),
            'fbs': request.form.get('fbs', '0').strip(),
            'exang': request.form.get('exang', '0').strip(),
            'oldpeak': request.form.get('oldpeak', '0.0').strip(),
            'restecg': request.form.get('restecg', '0').strip(),
            # Hypertension specific
            'systolic_bp': request.form.get('systolic_bp', '').strip(),
            'diastolic_bp': request.form.get('diastolic_bp', '').strip(),
            # Asthma specific symptoms
            'difficulty_breathing': request.form.get('difficulty_breathing', '0').strip(),
            'dry_cough': request.form.get('dry_cough', '0').strip(),
            'nasal_congestion': request.form.get('nasal_congestion', '0').strip(),
            'sore_throat': request.form.get('sore_throat', '0').strip(),
            'tiredness': request.form.get('tiredness', '0').strip(),
            'runny_nose': request.form.get('runny_nose', '0').strip(),
            'pains': request.form.get('pains', '0').strip()
        }

        form_data = {**personal_info, **health_data, 'disease': disease}

        try:
            # 1. Execute disease risk analysis
            eval_res = analyze_disease_risk(disease, personal_info, health_data)

            if not eval_res.get('success'):
                error_message = eval_res.get('error', 'Prediction model not available.')
            else:
                # 2. Automatically save successful assessment to SQLite
                saved_record_id = save_assessment(eval_res)

                # 3. Redirect to results view to avoid duplicate on refresh (PRG pattern)
                return redirect(url_for('risk_analysis_view', record_id=saved_record_id, disease=disease))

        except Exception as e:
            error_message = str(e)

    return render_template(
        'risk_analysis.html',
        selected_disease=selected_disease,
        result=assessment_result,
        error=error_message,
        form_data=form_data
    )


# ---------------- 3. Patient Record ----------------

@app.route('/patient-records')
def patient_record_view():
    """
    Patient Record Section:
    Searchable, filterable, sortable registry of all saved patient analyses.
    """
    search_query = request.args.get('search', '').strip()
    disease_filter = request.args.get('disease', 'All').strip()
    sort_order = request.args.get('sort', 'desc').strip()

    records = get_all_assessments(
        search=search_query if search_query else None,
        disease_filter=disease_filter,
        sort_order=sort_order
    )

    return render_template(
        'patient_record.html',
        records=records,
        search_query=search_query,
        disease_filter=disease_filter,
        sort_order=sort_order
    )


@app.route('/patient-records/<record_id>')
def patient_record_detail(record_id):
    """
    View Details:
    Retrieves the original saved analysis record from SQLite database.
    Does not regenerate or re-run any prediction.
    """
    record = get_assessment_by_id(record_id)
    if not record:
        flash(f"Patient record '{record_id}' not found.", "warning")
        return redirect(url_for('patient_record_view'))

    return render_template('patient_detail.html', record=record)


# ---------------- 4. Dataset (50,000 Records) ----------------

@app.route('/dataset')
def dataset_view():
    """
    Healthcare Dataset Section:
    Displays overview statistics, feature dictionary, decentralized hospital splits,
    and preview of the 50,000 clinical records.
    """
    summary = get_dataset_summary()
    return render_template('dataset.html', summary=summary)


@app.route('/dataset/download/<filename>')
def download_dataset(filename):
    """
    Direct download endpoint for datasets:
    Supports diabetes_50k.csv, asthma_50k.csv, diabetes.csv, hospital_A.csv, etc.
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    allowed_files = [
        'diabetes_50k.csv',
        'asthma_50k.csv',
        'heart_50k.csv',
        'hypertension_50k.csv',
        'diabetes.csv',
        'heart.csv',
        'hypertension.csv',
        'hospital_A.csv',
        'hospital_B.csv',
        'hospital_C.csv',
        'test_data.csv'
    ]
    if filename not in allowed_files:
        flash(f"File '{filename}' is not available for download.", "warning")
        return redirect(url_for('dataset_view'))
    return send_from_directory(data_dir, filename, as_attachment=True)


# ---------------- 5. Hadoop Storage & Infrastructure ----------------

@app.route('/hadoop', methods=['GET', 'POST'])
def hadoop_view():
    """
    Hadoop HDFS Storage Page:
    Displays WebHDFS connection status, cluster settings, and multi-tenant hospital directories.
    """
    if request.method == 'POST':
        action = request.form.get('action', '').strip()
        if action == 'save_config':
            new_cfg = {
                'host': request.form.get('host', 'localhost').strip(),
                'port': int(request.form.get('port', 9870)),
                'user': request.form.get('user', 'hadoop').strip(),
                'base_hdfs_path': request.form.get('base_path', '/healthcare_dfs').strip()
            }
            save_hadoop_config(new_cfg)
            flash("Hadoop WebHDFS configuration saved successfully.", "success")
            return redirect(url_for('hadoop_view'))

        elif action == 'upload':
            res = upload_datasets_to_hdfs()
            if res.get('success'):
                flash(f"Success: {res.get('message')}", "success")
            else:
                flash(f"{res.get('message')}", "info")
            return redirect(url_for('hadoop_view'))

    storage = get_hdfs_storage_status()
    return render_template('hadoop.html', storage=storage)

# ---------------- 6. HDFS Data Contribution & Model Retraining ----------------

@app.route('/hdfs/upload', methods=['GET', 'POST'])
def hdfs_upload():
    """Allow a hospital to upload a CSV which is de‑identified and appended to the shared HDFS file."""
    if request.method == 'POST':
        uploaded_file = request.files.get('csv_file')
        hospital_id = request.form.get('hospital_id', 'unknown')
        if not uploaded_file:
            flash('No file selected.', 'warning')
            return redirect(url_for('hdfs_upload'))
        try:
            df = pd.read_csv(uploaded_file)
            # De‑identify PII before upload
            df_clean = deidentify_dataframe(df)
            upload_to_hdfs(df_clean, hospital_id=hospital_id)
            flash(f'File uploaded and merged into HDFS (rows={len(df_clean)}).', 'success')
        except Exception as e:
            flash(f'Upload failed: {e}', 'danger')
        return redirect(url_for('hdfs_upload'))
    return render_template('hdfs_upload.html')

@app.route('/hdfs/retrain', methods=['POST'])
def hdfs_retrain():
    """Retrain the global model on the combined HDFS dataset."""
    try:
        result = retrain_global_model_from_hdfs()
        flash(f"{result['message']} Accuracy={result['accuracy_percent']}%", 'success')
    except Exception as e:
        flash(f'Retraining failed: {e}', 'danger')
    return redirect(url_for('hdfs_upload'))

@app.route('/hdfs/analytics')
def hdfs_analytics():
    """Run the mrjob MapReduce stats job and display aggregated population analytics."""
    try:
        stats = run_hadoop_stats_job()
    except Exception as e:
        flash(f'Analytics job failed: {e}', 'danger')
        stats = []
    return render_template('hdfs_analytics.html', stats=stats)



# ---------------- Backward Compatibility & Backend APIs ----------------

@app.route('/predict', methods=['GET', 'POST'])
def legacy_predict_redirect():
    """Redirects legacy prediction path to Risk Analysis."""
    return redirect(url_for('risk_analysis_view'))


@app.route('/api/train-federated', methods=['POST'])
def api_train_federated():
    """Internal API: Trigger Federated Learning training pipeline."""
    try:
        results = run_federated_pipeline()
        return jsonify({
            'status': 'success',
            'message': 'Federated learning pipeline executed successfully. Model parameters aggregated.',
            'results': results
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/predict', methods=['POST'])
def api_predict():
    """Internal API: Predict diabetes risk from raw JSON."""
    try:
        data = request.get_json(force=True)
        res = predict_diabetes_risk(data)
        return jsonify({'status': 'success', 'data': res})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400


@app.route('/api/hadoop-test', methods=['GET'])
def api_hadoop_test():
    """Internal API: Tests Hadoop connection status."""
    cfg = get_hadoop_config()
    conn = check_hadoop_connection(cfg.get('host'), cfg.get('port'))
    return jsonify(conn)


if __name__ == '__main__':
    import socket
    local_ip = '127.0.0.1'
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        pass

    print("=" * 70)
    print("Privacy-Preserving Healthcare Analytics Web Application")
    print("Main Sections: 1. Dashboard | 2. Risk Analysis | 3. Patient Record")
    print(f"Local Access:   http://127.0.0.1:5000")
    print(f"Mobile Access:  http://{local_ip}:5000 (connect to same Wi-Fi)")
    print("=" * 70)
    app.run(host='0.0.0.0', port=5000, debug=True)
